#!/usr/bin/env python3
"""Run unchanged packaged entry points and sample their actual mapped libraries.

This observer never imports/patches the runner or reads keys, environment,
database files, or process command lines. Only owned vendor executables and
their mapped vendor/system files are inventoried. It is supplementary evidence,
not a claim to have sampled every subprocess or all earlier experiments.
"""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import time


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def sample(lab, observations, seen):
    vendor = str(lab / 'vendor') + '/'
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            executable = os.readlink(proc / 'exe')
            if not executable.startswith(vendor):
                continue
            lines = (proc / 'maps').read_text().splitlines()
            allowed = []
            for line in lines:
                fields = line.split(maxsplit=5)
                if len(fields) != 6:
                    continue
                path = fields[-1]
                if path.startswith((vendor, '/usr/lib/', '/lib/')):
                    allowed.append(line)
            paths = sorted({line.split(maxsplit=5)[-1] for line in allowed})
            identity = (executable, tuple(paths))
            if identity in seen:
                continue
            files = []
            for name in paths:
                path = Path(name)
                files.append({'path': name, 'sha256': sha(path), 'bytes': path.stat().st_size})
            observations.append({
                'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'pid': int(proc.name), 'exe': executable, 'maps': allowed, 'files': files,
            })
            seen.add(identity)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue  # A short-lived client can exit during a /proc sample.


def run(command, output, lab, observations, seen):
    with output.open('x') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, cwd=lab)
        deadline = time.monotonic() + 900
        while process.poll() is None:
            sample(lab, observations, seen)
            if time.monotonic() >= deadline:
                process.terminate()
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                raise RuntimeError('runner deadline exceeded; discard result and stop container')
            time.sleep(.03)
        if process.returncode:
            raise RuntimeError(f'runner exited {process.returncode}; see {output}')


def main(lab, round_name, control_name, report):
    if not re.fullmatch(r"/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*", str(lab)):
        raise RuntimeError('simple absolute lab path required')
    if not all(re.fullmatch(r"[A-Za-z0-9_-]+", name) for name in (round_name, control_name)):
        raise RuntimeError('simple run names required')
    if report.exists():
        raise RuntimeError('refusing to overwrite runtime report')
    observations, seen = [], set()
    status = {'pass': False, 'round': round_name, 'control': control_name,
              'observer_sha256': sha(Path(__file__)), 'observations': observations}
    try:
        run([sys.executable, str(lab / 'src/run_matrix.py'), '--name', round_name],
            lab / 'artifacts' / f'{round_name}-console.log', lab, observations, seen)
        run([sys.executable, str(lab / 'src/run_clean_provider_control.py'),
             '--base', round_name, '--name', control_name],
            lab / 'artifacts' / f'{control_name}-console.log', lab, observations, seen)
        for name in ['postgres', 'pgbackrest']:
            matches = [o for o in observations if Path(o['exe']).name == name
                       and any(f['path'].endswith('/libssl.so.3') for f in o['files'])
                       and any(f['path'].endswith('/libcrypto.so.3') for f in o['files'])]
            if name == 'postgres':
                matches = [o for o in matches if any(f['path'].endswith('/pg_tde.so') for f in o['files'])]
            if not matches:
                raise RuntimeError('no complete live library observation for ' + name)
        status['pass'] = True
    except Exception as error:
        status['error'] = str(error)
        raise
    finally:
        report.write_text(json.dumps(status, indent=2) + '\n')
    print(json.dumps({'pass': True, 'unique_observations': len(observations), 'report': str(report)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--lab', type=Path, required=True)
    parser.add_argument('--round', required=True)
    parser.add_argument('--control', required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    main(args.lab, args.round, args.control, args.report)
