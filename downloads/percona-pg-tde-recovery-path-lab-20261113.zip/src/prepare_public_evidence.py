#!/usr/bin/env python3
"""Validate a private staging archive and create a narrowly sanitized evidence copy.

This does not make an arbitrary archive safe to publish: use the tested allowlist
exporter first and review the output. No database, key or credential is accessed.
"""
import argparse, hashlib, json, pathlib, re, zipfile

def prepare(source, destination):
    if destination.exists(): raise RuntimeError('output already exists; refusing overwrite')
    archive=source.read_bytes()
    with zipfile.ZipFile(source) as z:
        manifest=json.loads(z.read('EVIDENCE_MANIFEST.json'))
        records=[]; output=[]; seen=set(); redactions=[]
        for row in manifest['files']:
            name=row['path']; path=pathlib.PurePosixPath(name)
            if path.is_absolute() or '..' in path.parts or '\\' in name or name in seen or name=='EVIDENCE_MANIFEST.json':
                raise RuntimeError('unsafe or duplicate manifest path')
            seen.add(name); data=z.read(name)
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise RuntimeError('input manifest mismatch: '+name)
            clean,count=re.subn(rb'(?m)^(Mock authentication nonce:)[^\r\n]*',rb'\1 [REDACTED: unrelated authentication metadata]',data)
            records.append({'path':name,'bytes':len(clean),'sha256':hashlib.sha256(clean).hexdigest(),'original_sha256':row['sha256'],'redacted_lines':count})
            if count:redactions.append({'path':name,'lines':count,'field':'Mock authentication nonce'})
            output.append((name,clean))
    destination.mkdir(parents=True)
    for name,data in output:
        target=destination/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
    result={'description':'Verified staging archive; only listed unrelated authentication nonce fields redacted. Other bytes unchanged. Review before publishing.','source_archive_sha256':hashlib.sha256(archive).hexdigest(),'runs':manifest['runs'],'files':records,'redactions':redactions}
    (destination/'EVIDENCE_MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True)
    a=ap.parse_args();r=prepare(a.input,a.output)
    print(json.dumps({'files_verified':len(r['files']),'redacted_files':len(r['redactions']),'destination':str(a.output)}))
