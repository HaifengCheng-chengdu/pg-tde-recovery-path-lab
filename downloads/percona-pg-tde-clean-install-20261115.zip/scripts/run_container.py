#!/usr/bin/env python3
"""Japan-only container controller. All cleanup uses its exact created CID.

Never invokes privileged containers, host network, Docker-socket mounts, or
changes host configuration. A wall deadline and every failure stop only this
invocation's container, then record its final running/exit state.
"""
import argparse
import hashlib
import os
import json
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path('/home/researchadmin/percona-clean-repro-20261115')
BASE = 'debian@sha256:7378260c0a098d27ac206225db5e7d92b8c7c84ea7afccc86eeb513756bbd392'
LABEL = 'org.haifeng.percona-clean=20261115'


def docker(args, timeout=90, check=True):
    return subprocess.run(['sudo', '-n', 'docker', *args], text=True,
                          capture_output=True, timeout=timeout, check=check)


def validate_root(root):
    if not re.fullmatch(r"/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)+", str(root)):
        raise RuntimeError('simple absolute root with at least two components required')
    if root.resolve() != root or not root.is_dir() or root.stat().st_uid != os.getuid():
        raise RuntimeError('root must be a real directory owned by the invoking user')
    for name in ('inputs', 'scripts', 'records'):
        path = root / name
        if path.is_symlink() or not path.is_dir() or path.stat().st_uid != os.getuid():
            raise RuntimeError('input, script and record directories must be owned real directories')
    return root


def stop_on_signal(signum, frame):
    raise RuntimeError('controller interrupted by signal ' + str(signum))


def main(phase, image, deadline):
    if phase not in {'provision', 'r1', 'r2', 'timeout-selftest'}:
        raise RuntimeError('unsupported phase')
    if ROOT.is_symlink() or not ROOT.is_dir() or Path.cwd() != ROOT:
        raise RuntimeError('run only from the new Japan reproduction root')
    if phase in {'r1', 'r2'} and not re.fullmatch(r'sha256:[0-9a-f]{64}', image or ''):
        raise RuntimeError('experiment requires an immutable local dependency image ID')
    report = ROOT / 'records' / (phase + '-container.json')
    logfile = ROOT / 'records' / (phase + '-container.log')
    if report.exists() or logfile.exists():
        raise RuntimeError('fresh record paths required')
    prefix = ['create', '--name', 'percona-clean-20261115-' + phase,
              '--label', LABEL, '--cpus', '2', '--memory', '4g',
              '--memory-swap', '4g', '--pids-limit', '256', '--shm-size', '256m']
    if phase == 'provision':
        args = prefix + ['--mount', f'type=bind,src={ROOT}/scripts,dst=/scripts,readonly',
                         BASE, 'bash', '/scripts/provision.sh']
    elif phase == 'timeout-selftest':
        args = prefix + ['--network', 'none', BASE, 'sleep', '60']
    else:
        work = ROOT / phase
        work.mkdir(mode=0o700)  # No reuse of an old filesystem or vendor tree.
        args = prefix + ['--network', 'none', '--user', '1000:1000', '--cap-drop', 'ALL',
                         '--security-opt', 'no-new-privileges',
                         '--mount', f'type=bind,src={ROOT}/inputs,dst=/inputs,readonly',
                         '--mount', f'type=bind,src={ROOT}/scripts,dst=/scripts,readonly',
                         '--mount', f'type=bind,src={work},dst=/work',
                         image, 'bash', '/scripts/run_inside.sh', phase]
    cid = docker(args).stdout.strip()
    if not re.fullmatch(r'[0-9a-f]{64}', cid):
        raise RuntimeError('unexpected create response; inspect named container before retry')
    status = {'phase': phase, 'cid': cid, 'create_arguments': args,
              'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'controller_returncode': None, 'deadline_seconds': deadline,
              'controller_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, stop_on_signal)
    error = None
    try:
        with logfile.open('x') as log:
            process = subprocess.Popen(['sudo', '-n', 'docker', 'start', '-a', cid],
                                       stdout=log, stderr=subprocess.STDOUT)
            try:
                status['controller_returncode'] = process.wait(timeout=deadline)
            except subprocess.TimeoutExpired:
                status['timed_out'] = True
                raise RuntimeError('wall deadline exceeded')
        if status['controller_returncode'] != 0:
            raise RuntimeError('container command failed')
    except Exception as exc:
        error = exc
        status['error'] = str(exc)
    finally:
        # Exact identity from this invocation, never a name wildcard/process scan.
        inspect = json.loads(docker(['inspect', cid]).stdout)[0]
        if inspect['Config']['Labels'].get('org.haifeng.percona-clean') != '20261115':
            raise RuntimeError('container ownership label changed; stop not attempted')
        if inspect['State']['Running']:
            stopped = docker(['stop', '--time', '20', cid], timeout=45, check=False)
            status['stop_returncode'] = stopped.returncode
        final = json.loads(docker(['inspect', cid]).stdout)[0]
        status['final_state'] = final['State']
        status['host_config'] = {k: final['HostConfig'][k] for k in
                                ['NanoCpus', 'Memory', 'MemorySwap', 'PidsLimit',
                                 'NetworkMode', 'Privileged', 'PortBindings', 'Binds']}
        status['mounts'] = final['Mounts']
        status['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        report.write_text(json.dumps(status, indent=2) + '\n')
        if final['State']['Running']:
            raise RuntimeError('owned container still running; report exact CID')
        if 'process' in locals():
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.terminate()  # Docker client only; container already stopped.
                process.wait(timeout=10)
    if error:
        raise error
    if status['final_state']['ExitCode'] != 0:
        raise RuntimeError('container exit state was not successful')
    print(json.dumps({'pass': True, 'cid': cid, 'report': str(report)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--phase', required=True)
    parser.add_argument('--image')
    parser.add_argument('--deadline', type=int, default=1200)
    options = parser.parse_args()
    if not 1 <= options.deadline <= 1800:
        parser.error('deadline must be 1..1800 seconds')
    ROOT = validate_root(options.root)
    main(options.phase, options.image, options.deadline)
