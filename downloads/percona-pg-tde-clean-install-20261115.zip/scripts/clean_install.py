#!/usr/bin/env python3
"""New 2026-11-14 installer, not a reconstruction of the original commands.

Run as an unprivileged user in a disposable Debian 13 container. The two input
archives are immutable, hash-pinned inputs. Never reuse a lab directory.
"""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile
import time
import zipfile

ZIP_SHA = 'cc2fbd7bfeb53e182be666d3c6d3c8da4abe1588ea1b834823472c9cf738ad30'
TAR_SHA = '992008f839865fc240848a8eb4c3e7ae76ecf221479bfd17f67a146611186300'
BINARY_SHA = {
    'percona-postgresql18/bin/postgres': '93dfcfecbf193fbff3ffa5b9c4cfe11f26f0c18a29ab16dc3b09d70c223758f3',
    'percona-postgresql18/lib/pg_tde.so': '1a1b3158524058d0e0eb61e6448605d67f3c5693623f1a46f121cc597185ad8d',
    'percona-pgbackrest/bin/pgbackrest': '7bf333939cc7892caf4aef8cba3858dd7bb85df02bfa2f71cf00b990e7591e2f',
}
TOP_LEVEL = {'percona-etcd', 'percona-gdal', 'percona-haproxy', 'percona-patroni',
             'percona-perl', 'percona-pgbackrest', 'percona-pgbadger',
             'percona-pgbouncer', 'percona-pgpool-II', 'percona-postgresql18',
             'percona-proj', 'percona-python3', 'percona-tcl'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name:
        raise RuntimeError('unsafe archive path: ' + name)
    return path


def command(args, cwd=None):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True,
                            timeout=120, env={**os.environ, 'LC_ALL': 'C', 'TZ': 'UTC'})
    if result.returncode:
        raise RuntimeError(f'{args[0]} failed ({result.returncode}): {result.stderr}')
    return result.stdout


def main(companion, tarball, lab, report):
    if os.geteuid() == 0:
        raise RuntimeError('database installation must run as non-root')
    if lab.exists() or report.exists():
        raise RuntimeError('fresh lab and report paths required; refusing overwrite')
    for path, expected in [(companion, ZIP_SHA), (tarball, TAR_SHA)]:
        if sha(path) != expected:
            raise RuntimeError('input SHA-256 mismatch: ' + str(path))
    if not re.fullmatch(r"/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*", str(lab)):
        raise RuntimeError('lab path must use only absolute ASCII alphanumeric, underscore, hyphen components')
    openssl = command(['openssl', 'version'])
    if not openssl.startswith('OpenSSL 3.5.'):
        raise RuntimeError('this supplement requires OpenSSL 3.5.x')
    os.umask(0o077)
    lab.mkdir(parents=True)
    with zipfile.ZipFile(companion) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError('duplicate ZIP paths')
        for item in archive.infolist():
            safe_name(item.filename)
            if stat.S_ISLNK(item.external_attr >> 16):
                raise RuntimeError('unexpected ZIP symlink')
        archive.extractall(lab)
    original_check = command(['sha256sum', '-c', 'CHECKSUMS.sha256'], cwd=lab)
    vendor = lab / 'vendor'
    vendor.mkdir()
    with tarfile.open(tarball, 'r:gz') as archive:
        members = archive.getmembers()
        tops = {safe_name(m.name).parts[0] for m in members}
        if tops != TOP_LEVEL:
            raise RuntimeError('unexpected tar layout')
        # Components are directly at the archive root. No strip-components.
        # Python's data filter rejects out-of-tree links and special files.
        archive.extractall(vendor, filter='data')
    binary_records = []
    for name, expected in BINARY_SHA.items():
        path = vendor / name
        if sha(path) != expected:
            raise RuntimeError('installed binary SHA-256 mismatch: ' + name)
        deps = command(['ldd', str(path)])
        if 'not found' in deps:
            raise RuntimeError('unresolved dynamic dependency: ' + name)
        binary_records.append({'path': name, 'sha256': expected, 'ldd': deps})
    for name in ['runs', 'artifacts']:
        (lab / name).mkdir()
    record = {
        'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'uid': os.getuid(), 'lab': str(lab),
        'companion_sha256': ZIP_SHA, 'distribution_tarball_sha256': TAR_SHA,
        'zip_checksum_check': original_check,
        'archive_entries': len(members), 'archive_top_level': sorted(tops),
        'extraction': "tarfile.extractall(vendor, filter='data'); no strip-components",
        'openssl_version': openssl.strip(),
        'os_release': Path('/etc/os-release').read_text(),
        'packages': command(['dpkg-query', '-W', '-f=${binary:Package}\t${Version}\n']),
        'binaries': binary_records,
        'runner_sha256': sha(lab / 'src/run_matrix.py'),
        'control_sha256': sha(lab / 'src/run_clean_provider_control.py'),
        'installer_sha256': sha(Path(__file__)),
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'pass': True, 'report': str(report), 'archive_entries': len(members)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--companion', type=Path, required=True)
    parser.add_argument('--tarball', type=Path, required=True)
    parser.add_argument('--lab', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    main(args.companion, args.tarball, args.lab, args.report)
