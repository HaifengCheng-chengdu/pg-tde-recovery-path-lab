#!/usr/bin/env python3
"""Allowlist export of this dated supplement; never exports whole work directories."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

RECORDS = [
    'base-image-inspect.json', 'base-image-pull.log', 'input-sha256.txt',
    'dependency-image-id.txt', 'dependency-image-inspect.json', 'package-lock.tsv',
    'provision-container.json', 'provision-container.log', 'setup-start.txt',
    'tarball-download.log', 'timeout-selftest-container.json',
    'timeout-selftest-container.log', 'timeout-selftest-controller.log',
    'r1-container.json', 'r1-container.log', 'r2-container.json', 'r2-container.log',
    'run_container-r1.py', 'run_container-r1.sha256',
]
SCRIPTS = ['clean_install.py', 'run_observed.py', 'run_container.py',
           'provision.sh', 'run_inside.sh', 'export_supplement.py']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe(name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name:
        raise RuntimeError('unsafe evidence name')


def main(root, output):
    if output.exists():
        raise RuntimeError('refusing to overwrite supplement')
    entries = {}

    def add(path, name):
        safe(name)
        if name in entries or path.is_symlink() or not path.is_file():
            raise RuntimeError('missing, linked, or duplicate export input: ' + name)
        entries[name] = path.read_bytes()

    for name in RECORDS:
        add(root / 'records' / name, 'records/' + name)
    ownership = root / 'records/r2-openssl-package-ownership.txt'
    if ownership.is_file():
        add(ownership, 'records/r2-openssl-package-ownership.txt')
    for name in SCRIPTS:
        add(root / 'scripts' / name, 'scripts/' + name)
    secrets = []
    for run in ('r1', 'r2'):
        for name in ('install.json', 'runtime-libraries.json', 'private-audit.json', 'evidence-audit.json'):
            add(root / run / name, run + '/' + name)
        report = json.loads(entries[run + '/evidence-audit.json'])
        runtime = json.loads(entries[run + '/runtime-libraries.json'])
        if not report['pass'] or report['core_cases'] != 9 or not runtime['pass']:
            raise RuntimeError('experiment or runtime inventory did not pass')
        evidence = root / run / 'evidence'
        manifest = json.loads((evidence / 'EVIDENCE_MANIFEST.json').read_text())
        add(evidence / 'EVIDENCE_MANIFEST.json', run + '/evidence/EVIDENCE_MANIFEST.json')
        for row in manifest['files']:
            safe(row['path'])
            path = evidence / row['path']
            data = path.read_bytes()
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise RuntimeError('evidence manifest mismatch')
            add(path, run + '/evidence/' + row['path'])
        for config in (root / run / 'lab/runs').glob('*/pgbackrest.conf'):
            for line in config.read_text().splitlines():
                if line.startswith('repo1-cipher-pass='):
                    secrets.append(line.split('=', 1)[1].encode())
    if len(secrets) != 2:
        raise RuntimeError('expected exactly one repository credential per matrix')
    for name, data in entries.items():
        if any(secret in data for secret in secrets):
            raise RuntimeError('generated repository credential in export candidate: ' + name)
    manifest = {
        'description': 'Two fresh container filesystems, one freshly provisioned frozen dependency image. '
                       'Only explicit reports/scripts and manifest-verified sanitized evidence included.',
        'credential_scan': 'No generated repository passphrase found. Key files, PGDATA, repositories, '
                           'configuration files and binary software archives excluded by allowlist.',
        'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                  for name, data in sorted(entries.items())],
    }
    with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(entries.items()):
            archive.writestr(name, data)
        archive.writestr('SUPPLEMENT_MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'pass': True, 'file': str(output), 'files': len(entries),
                      'bytes': output.stat().st_size, 'sha256': sha(output.read_bytes())}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    main(args.root, args.output)
