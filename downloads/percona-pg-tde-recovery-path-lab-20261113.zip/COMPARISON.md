# Comparison with existing work

The review covered Percona Community's sitemap (approximately 337 indexed titles), targeted Community and main-blog searches, official pg_tde documentation, and closely related external articles. It did not read every historical full text or inspect unpublished submissions. Links below identify the relevant comparators; this is not a global literature completeness claim.

| Existing work | Strength already present | Distinct contribution in this candidate | Remaining trade-off |
|---|---|---|---|
| [Haifeng's first Percona article, 12 November](https://percona.community/blog/2026/11/12/postgresql-restore-ownership-acls-default-privileges/) | Pinned PostgreSQL 18.4 lab; 70 positive/negative checks; ownership/ACL/default-privilege boundaries and SQLSTATE evidence; practical SQL walkthrough | Time-dependent key dependencies across explicit recovery targets; version-matched WAL redo mechanism; startup versus completed-recovery distinction; measured CLI control-file-state boundary | The first article's step-by-step SQL teaching is stronger. This candidate relies more heavily on the companion runner. Merely having negative tests or many checks is not an advantage over the first article. |
| [Percona's March pgBackRest/pg_tde walkthrough](https://percona.community/blog/2026/03/10/running-pgbackrest-with-pg_tde-a-practical-percona-walkthrough/) | Setup, wrappers, encrypted repository, verify, restore, sample queries | Controlled backup-to-target × database-key availability matrix; full-payload equality and exact LSN; stage-specific negative evidence | Narrower scope and no external KMS deployment guide. |
| [Stefan Fercot's pgBackRest and pg_tde experiments](https://pgstef.github.io/2026/06/04/pgbackrest_and_pg_tde.html) | OpenBao, PITR, incremental backups and WAL-workflow experiments | Fixed documented WAL workflow, isolated principal-key availability, repeated causal recovery checks | Does not surpass the comparator's KMS/incremental coverage; ordinary PITR is not new here. |
| [Percona backup recovery documentation](https://docs.percona.com/pg-tde/how-to/restore-backups.html) and [key-provider overview](https://docs.percona.com/pg-tde/global-key-provider-configuration/overview.html) | Older backups require older keys; rotate outside backups; take a new full backup; repair provider configuration | Makes a recovery-path retention test executable and exposes the fresh-restore/clean-shutdown CLI precondition with a distinct positive control | These operational principles are known facts, not discoveries. |

The useful advantage is a traceable causal lab and reusable acceptance test, not novelty of the basic encryption requirement. It fits Percona's practical database-recovery focus and [community writing programme](https://percona.community/blog/2026/05/22/write-for-percona-community/), but a new topic still needs editorial consideration.

## Quality checks completed

- Same frozen runner, three fresh source/backup/key rounds.
- Exact per-run target LSN and full-payload evidence for successful recovery.
- Missing-key errors tied to immediately adjacent same-process redo context.
- Separate negative stale-path and positive clean-shutdown repair controls.
- Source-code explanation pinned to pg_tde 2.2.2.
- Independent checking of counts, versions, all 23 raw CSV hashes and publication wording.
- Clear disclosures, limitations, official-source citations, and sanitized evidence with checksums.

## Remaining limitations before calling it a broader operational guide

- No fresh-host package installation replay or dynamic-library resolution inventory.
- One provider model, one database, one key transition and a small synthetic dataset.
- No production KMS access policy, operational key escrow drill, scale or performance result.
- No proof of universal first publication or a numerical rank among all technical articles.

The draft is technically supported within its stated scope. These comparisons do not justify an unqualified claim that it is the best or that editorial acceptance is assured.
