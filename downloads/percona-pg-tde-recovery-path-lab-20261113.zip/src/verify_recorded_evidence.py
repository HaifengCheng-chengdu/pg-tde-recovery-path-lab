#!/usr/bin/env python3
"""Read-only audit of recorded lab evidence. Does not start PostgreSQL."""
import argparse, hashlib, json, pathlib, re

def check(value, message):
    if not value: raise RuntimeError(message)

def sha(data): return hashlib.sha256(data).hexdigest()
def read_json(path): return json.loads(path.read_text())
def event_log(root, events, label):
    found=[e for e in events if e['label']==label]
    check(len(found)==1, f'{root.name}: expected one event {label}')
    return (root/found[0]['log']).read_bytes(), found[0]
def payload_check(root, events, label, digest):
    raw,event=event_log(root,events,label)
    check(event['returncode']==0,f'{label}: command failed')
    payload=raw.split(b'\n',1)[1]
    check(len(payload)==digest['bytes'] and sha(payload)==digest['sha256'],f'{label}: full raw CSV differs')

def main(runs_root, rounds, control, allow_unmanifested=False):
    manifest=runs_root.parent/'EVIDENCE_MANIFEST.json'
    files_verified=0
    check(manifest.is_file() or allow_unmanifested,'evidence manifest missing; use --allow-unmanifested only for fresh private runs before export')
    if manifest.is_file():
        for row in read_json(manifest)['files']:
            f=manifest.parent/row['path']; data=f.read_bytes()
            check(sha(data)==row['sha256'] and len(data)==row['bytes'],f'manifest mismatch: {row["path"]}')
            files_verified+=1
    positive={'old_before_both','old_before_k0','old_after_both','new_after_both','new_after_k1'}
    negative={'old_before_k1':'K0','old_after_k0':'K1','old_after_k1':'K0','new_after_k0':'K1'}
    output=[]; hashes=[]; runner_hashes=[]
    for name in rounds:
        root=runs_root/name; events=read_json(root/'events.json'); meta=read_json(root/'metadata.json'); results=read_json(root/'results.json')
        runner_hash=sha((root/'runner_snapshot.py').read_bytes()); runner_hashes.append(runner_hash)
        check((root/'runner_sha256.txt').read_text().strip()==runner_hash,f'{name}: runner snapshot hash mismatch')
        check(meta['pg_tde_version']=='pg_tde 2.2.2',f'{name}: different extension version')
        check(len(results)==11 and {r['case'] for r in results}==positive|set(negative)|{'provider_path_missing','provider_path_repaired'},f'{name}: case set differs')
        for phase in ['before','after']:payload_check(root,events,phase+'-digest',meta['expected'][phase])
        hashes.append([meta['expected'][k]['sha256'] for k in ['before','after']])
        for row in results:
            case=row['case']; check(row['verify_rc']==0 and row['restore_rc']==0,f'{name}/{case}: repository stage failed')
            check(row['expected_outcome_matches'],f'{name}/{case}: runner reports mismatch')
            if case in positive:
                expected=meta['expected'][row['target']]
                check(row['stage']=='pass' and row['matches_expected'] and row['named_target_in_log'],f'{name}/{case}: acceptance failed')
                check(row['replay_lsn']==meta['targets'][row['target']]==row['expected_target_lsn'],f'{name}/{case}: target mismatch')
                check(row['target_output']=='f\n'+row['target'],f'{name}/{case}: recovery/marker mismatch')
                for field in ['sha256','bytes','rows','access_method','encrypted','index']:
                    check(row['digest'][field]==expected[field],f'{name}/{case}: {field} differs')
                payload_check(root,events,case+'-digest',row['digest'])
                check(any('Index' in n for n in row['digest']['index_plan']),f'{name}/{case}: no index-based plan')
            elif case=='provider_path_repaired':
                check(row['stage']=='offline-provider-guard' and row['repair_rc']==1 and row['guard_matches'],f'{name}: fresh-restore CLI guard differs')
                data,_=event_log(root,events,case+'-control-data')
                check(b'Database cluster state:               in production' in data,f'{name}: unexpected fresh control state')
            else:
                key=negative.get(case,'K0'); text=(root/'logs'/f'{case}-start-server.log').read_text()
                lines=text.splitlines(); pairs=[]
                for i,line in enumerate(lines[:-1]):
                    if 'FATAL:' in line and '"'+key+'"' in line and 'WAL redo' in lines[i+1]:
                        a=re.search(r'\[(\d+)\]',line); b=re.search(r'\[(\d+)\]',lines[i+1])
                        if a and b and a.group(1)==b.group(1):pairs.append((line,lines[i+1]))
                check(pairs,f'{name}/{case}: missing same-process adjacent key error and redo context')
                if case=='old_after_k0':check(any('pg_tde/ROTATE_PRINCIPAL_KEY' in b for a,b in pairs),f'{name}: no causal rotation redo')
        output.append({'round':name,'core_successes':5,'core_missing_key_failures':4,'additional_missing_path':1,'fresh_restore_cli_guard':1,'first_command_utc':events[0]['started_at_utc'],'last_command_started_utc':events[-1]['started_at_utc']})
    check(all(x==hashes[0] for x in hashes),'source payloads vary between rounds')
    check(len(set(runner_hashes))==1,'runner changed between rounds')
    root=runs_root/control; c=read_json(root/'results.json'); events=read_json(root/'events.json')
    check(c['pass'] and c['failure_matches'] and c['missing_path_rc']==1 and c['repair_rc']==0 and c['baseline_matches_source'] and c['repair_matches_source'],'clean-shutdown control failed')
    check(c['digest']['sha256']==hashes[0][1],'clean control is not same after-state')
    for label in ['baseline','repaired']:payload_check(root,events,label,c['digest'])
    for label in ['initial-clean-control-data','before-offline-fix-control-data']:
        data,_=event_log(root,events,label); check(b'Database cluster state:               shut down' in data,'clean control was not shut down')
    print(json.dumps({'pass':True,'manifest_files_verified':files_verified,'unmanifested_fresh_runs':not manifest.is_file(),'rounds':output,'frozen_runner_sha256':runner_hashes[0],'core_cases':9*len(rounds),'successful_recoveries':5*len(rounds),'missing_key_recoveries':4*len(rounds),'source_hashes_before_after':hashes[0],'clean_provider_control_pass':True,'limits':'EXPLAIN plan evidence, not ANALYZE. Read-only verification of records is not a fresh database rerun.'},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runs-root',type=pathlib.Path,required=True);ap.add_argument('--rounds',nargs='+',required=True);ap.add_argument('--control',required=True)
    ap.add_argument('--allow-unmanifested',action='store_true',help='Only for fresh private runs before export; skip missing manifest, never an existing one')
    a=ap.parse_args();main(a.runs_root,a.rounds,a.control,a.allow_unmanifested)
