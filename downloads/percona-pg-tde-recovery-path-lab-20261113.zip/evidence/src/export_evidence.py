#!/usr/bin/env python3
"""Export only explicit non-secret evidence; never package a run directory wholesale."""
import argparse, hashlib, json, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main(names,destination):
    keep=[ROOT/'src/run_matrix.py',ROOT/'src/run_clean_provider_control.py',ROOT/'src/export_evidence.py']
    for name in names:
        run=ROOT/'runs'/name
        if not run.is_dir():raise RuntimeError('missing requested run '+name)
        for file in ['events.json','metadata.json','results.json','summary.json','runner_snapshot.py','runner_sha256.txt','control_runner_snapshot.py']:
            p=run/file
            if p.is_file():keep.append(p)
        keep.extend(sorted((run/'logs').glob('*.log')))
        c=ROOT/'artifacts'/f'{name}-console.log'
        if c.is_file():keep.append(c)
    passwords=[]
    for p in (ROOT/'runs').glob('*/pgbackrest.conf'):
        for line in p.read_text().splitlines():
            if line.startswith('repo1-cipher-pass='):passwords.append(line.split('=',1)[1].encode())
    manifests=[]
    for p in keep:
        data=p.read_bytes()
        if any(secret and secret in data for secret in passwords):
            raise RuntimeError('secret match in export candidate: '+str(p.relative_to(ROOT)))
        manifests.append({'path':str(p.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    dst=ROOT/'artifacts'/destination
    with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as z:
        for p in keep:z.write(p,str(p.relative_to(ROOT)))
        z.writestr('EVIDENCE_MANIFEST.json',json.dumps({'runs':names,'files':manifests,'credential_scan':'no generated repository passphrase found; config/key/PGDATA/repository excluded by allowlist'},indent=2))
    print(json.dumps({'file':str(dst),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'files':len(keep)}))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runs',nargs='+',required=True);ap.add_argument('--output',required=True)
    a=ap.parse_args();main(a.runs,a.output)
