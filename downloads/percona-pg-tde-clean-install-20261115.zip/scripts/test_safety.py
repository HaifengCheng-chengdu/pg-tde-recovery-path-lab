#!/usr/bin/env python3
"""Local regression checks. No database, Docker, credentials or network used."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


installer = load('clean_install')
observer = load('run_observed')
controller = load('run_container')


class SafetyChecks(unittest.TestCase):
    def test_archive_parent_absolute_and_backslash_rejected(self):
        for name in ['../bad', '/absolute', 'a/../bad', 'a\\bad']:
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                installer.safe_name(name)
        self.assertEqual(str(installer.safe_name('src/run_matrix.py')), 'src/run_matrix.py')

    def test_shell_active_lab_paths_rejected_before_command(self):
        for suffix in ['semi;colon', 'pipe|x', 'and&x', 'glob*', 'question?', 'dollar$x',
                       'back`x', 'quote"x', "quote'x", 'space x', 'line\nx', 'dot..x']:
            with tempfile.TemporaryDirectory() as root:
                with mock.patch.object(installer.os, 'geteuid', return_value=1000), \
                     mock.patch.object(installer, 'sha', side_effect=[installer.ZIP_SHA, installer.TAR_SHA]), \
                     mock.patch.object(installer, 'command') as command:
                    with self.subTest(suffix=suffix), self.assertRaises(RuntimeError):
                        installer.main(Path('/not-read.zip'), Path('/not-read.tar'),
                                       Path(root) / suffix, Path(root) / 'report.json')
                    command.assert_not_called()

    def test_root_execution_rejected(self):
        with mock.patch.object(installer.os, 'geteuid', return_value=0):
            with self.assertRaises(RuntimeError):
                installer.main(Path('/x'), Path('/y'), Path('/z'), Path('/r'))

    def test_observer_rejects_run_path_traversal(self):
        with mock.patch.object(observer, 'run') as run:
            for name in ['../other', 'x/y', 'x;id', 'x y']:
                with self.subTest(name=name), self.assertRaises(RuntimeError):
                    observer.main(Path('/work/lab'), name, 'control', Path('/work/report.json'))
            run.assert_not_called()

    def test_container_phase_rejected_before_docker(self):
        with mock.patch.object(controller, 'docker') as docker:
            with self.assertRaises(RuntimeError):
                controller.main('unowned', None, 10)
            docker.assert_not_called()

    def test_portable_root_rejects_symlinks_and_unsafe_paths(self):
        for root in ['/tmp/a;id', '/tmp/../tmp/lab', 'relative/path', '/']:
            with self.subTest(root=root), self.assertRaises(RuntimeError):
                controller.validate_root(Path(root))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in ['inputs', 'scripts', 'records']:
                (root / name).mkdir()
            self.assertEqual(controller.validate_root(root), root)
            (root / 'scripts').rmdir()
            (root / 'scripts').symlink_to(root / 'inputs')
            with self.assertRaises(RuntimeError):
                controller.validate_root(root)

    def test_existing_report_never_overwritten(self):
        with tempfile.TemporaryDirectory() as root:
            report = Path(root) / 'report.json'
            report.write_text('retained')
            with self.assertRaises(RuntimeError):
                observer.main(Path('/work/lab'), 'r1', 'c1', report)
            self.assertEqual(report.read_text(), 'retained')


if __name__ == '__main__':
    unittest.main()
