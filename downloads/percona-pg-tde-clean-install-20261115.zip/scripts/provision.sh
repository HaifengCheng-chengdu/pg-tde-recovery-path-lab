#!/bin/bash
# Executed only inside a new official Debian 13 container, never on the host.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive LC_ALL=C TZ=UTC
apt-get update
apt-get install -y --no-install-recommends python3=3.13.5-1 openssl=3.5.7-1~deb13u3 libreadline-dev=8.2-6
useradd --uid 1000 --create-home --shell /bin/bash lab
openssl version
python3 --version
dpkg-query -W -f='${binary:Package}\t${Version}\n' > /tmp/package-lock.tsv
cat /tmp/package-lock.tsv
