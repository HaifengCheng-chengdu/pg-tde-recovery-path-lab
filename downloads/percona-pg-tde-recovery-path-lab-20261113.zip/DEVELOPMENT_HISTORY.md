# Actual development history

All final experiment commands ran on 13 November 2026, UTC. The execution location was an authorised temporary Azure Japan West host, not Tokyo. Authoring and offline evidence review continued locally after the database processes were stopped. No production environment was used.

1. Initial Debian attempts completed initdb but could not create the required Unix-domain sockets (`Operation not permitted`). No database SQL/key/backup matrix ran there. A supported retry had the same result. No policy or host-security restriction was disabled.
2. After explicit authorisation for the alternative environment, the official archive was transferred through a hash-verified internal file transfer. A slow partial download and a failed regional download were not treated as valid binaries. The verified archive SHA-256 appears in PROVENANCE.json.
3. A first Japanese development run ended when the attached user session terminated. It is not counted as a completed round.
4. A subsequent pilot exposed a pgBackRest restore-command path mismatch. The restore wrapper was corrected to name the restored instance's pg1-path explicitly. Pilot output is not used for final acceptance.
5. The first upgraded run encountered the real offline provider-tool shutdown-state guard. The experiment was changed to record that refusal, not bypass it. A separate clean-shutdown positive control was then added.
6. The main runner was frozen at SHA-256 36184d2d80c85d3bf1e5e1383c86a5bfb54b1d4deb88cf5725264e7bbebcbb2d. Three complete final rounds ran from 17:24:21 through the last command started at 17:30:37 UTC. The distinct positive control ran at 17:31:21–17:31:22 UTC.
7. All lab PostgreSQL processes were stopped and the evidence saved locally before the shared host's resource window was returned at approximately 17:33 UTC. No later database load is claimed.
8. Offline review corrected overstatements about EXPLAIN versus ANALYZE, the host OpenSSL command versus loaded libraries, operation counts, pre-existing K1/provider setup and the fresh-restore repair boundary. The tested runner was not silently edited to match the prose.
9. Five unrelated pg_controldata authentication nonce fields were redacted only in the publication copy. The original private evidence archive was retained with SHA-256 71610ca09db8126ec4ebf34605c9e552a5aec644b05efcdb5eba744ca216bfc5. All 513 original file hashes were verified before sanitation; the public evidence also includes the separately recorded environment file.

Failed development attempts are described to make the selection of the final dataset explicit. Their private database trees and obsolete pre-experiment prose are not included in the publication candidate. This is a real development chronology, not a reconstructed Git history. No commit author, publication approval or production incident is fabricated.
