#!/usr/bin/env python3
"""Small offline regression tests for export hygiene and audit failure behavior."""
import hashlib,json,pathlib,tempfile,unittest,zipfile
from prepare_public_evidence import prepare
from verify_recorded_evidence import payload_check, main

class EvidenceTests(unittest.TestCase):
    def fixture(self,root,name='logs/control.log',bad_hash=False):
        data=b'Database cluster state:               shut down\nMock authentication nonce: local-test-value\n'
        digest=hashlib.sha256(data).hexdigest()
        manifest={'runs':['test'],'files':[{'path':name,'bytes':len(data),'sha256':'0'*64 if bad_hash else digest}]}
        source=root/'input.zip'
        with zipfile.ZipFile(source,'w') as z:z.writestr(name,data);z.writestr('EVIDENCE_MANIFEST.json',json.dumps(manifest))
        return source
    def test_only_nonce_redacted(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d); result=prepare(self.fixture(root),root/'out'); data=(root/'out/logs/control.log').read_bytes()
            self.assertNotIn(b'local-test-value',data);self.assertIn(b'Database cluster state:               shut down\n',data)
            self.assertEqual(result['files'][0]['redacted_lines'],1)
            self.assertEqual(hashlib.sha256(data).hexdigest(),result['files'][0]['sha256'])
    def test_tampered_manifest_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            with self.assertRaises(RuntimeError):prepare(self.fixture(root,bad_hash=True),root/'out')
            self.assertFalse((root/'out').exists())
    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            with self.assertRaises(RuntimeError):prepare(self.fixture(root,'../outside'),root/'out')
            self.assertFalse((root/'outside').exists())
    def test_existing_output_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);(root/'out').mkdir()
            with self.assertRaises(RuntimeError):prepare(self.fixture(root),root/'out')
    def test_missing_manifest_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(RuntimeError,"manifest missing"):
                main(pathlib.Path(d)/"runs",["r1"],"clean1")
    def test_raw_csv_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);(root/'payload.log').write_bytes(b'$ command\nchanged\n')
            events=[{'label':'digest','log':'payload.log','returncode':0}]
            with self.assertRaises(RuntimeError):payload_check(root,events,'digest',{'bytes':8,'sha256':hashlib.sha256(b'original').hexdigest()})
if __name__=='__main__':unittest.main()
