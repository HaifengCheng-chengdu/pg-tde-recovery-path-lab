# Clean-runtime supplement, 15 November 2026

This is new evidence, not a reconstruction of the unrecorded original installation commands. The 13 November companion ZIP and its original three rounds remain unchanged. No public release, editorial acceptance or production validation is claimed.

## What actually ran

One official Debian 13 amd64 image was freshly provisioned with pinned direct packages. Two separate containers then used that same frozen dependency image, each with a new writable directory, independently unpacked original companion ZIP, newly extracted official Percona tarball, new database, synthetic keys and backup repository. No old vendor tree or host libraries were mounted. This is **two clean filesystem/install replays on one host**, not two independent apt installations, two machines, or a new broad platform certification.

- r1: nine core cases, five complete recoveries, four causal missing-key failures; both provider-path negative controls and the separate clean-shutdown positive control passed. Its 193-file sanitized evidence manifest passes.
- r2: the same outcome; its 195-file manifest passes. Two additional normal target-polling logs explain the file-count difference, not extra cases.
- Both matrix payload hashes equal the original experiment: before `ee7f96205ac29a97a2c0b38f7511cdc54b897db80aca33a0b37c0fa03acea60c`; after `2c7373487671ad3bca5348fa2fcbd9dff8102aa7335f4556b529df7f5cf9cd9f`.
- Both used unchanged packaged main runner `36184d2d80c85d3bf1e5e1383c86a5bfb54b1d4deb88cf5725264e7bbebcbb2d` and control `cdf0dc453fe21feedfaa57cd2f8290f11183ca86833d80e18ce3b5b4b7870c40`.
- Main matrix commands ran 06:20:11–06:21:48 UTC and 06:23:37–06:25:33 UTC on 15 November. These are first/last matrix-command start times, not whole-container durations. The exact container and control timestamps are retained in the reports.
- Each experimental container was non-root UID 1000, limited to 2 CPU / 4 GiB, network disabled, and exposed no TCP port. All owned containers were stopped and verified again at 06:27:16 UTC. The isolated timeout self-test intentionally exited 137 after the controller stopped its exact CID; it is not a database result.

The official tarball documentation assigns the selected ssl3.5 build to OpenSSL 3.5.x. Actual `/proc/PID/maps` observations from both rounds include PostgreSQL with `pg_tde.so`, and pgBackRest, mapping the following files:

- `/usr/lib/x86_64-linux-gnu/libssl.so.3`: SHA-256 `9592038e92d1f41affcbb625334d0b6e788714c889104fa6d5b107cf9fd657f2`.
- `/usr/lib/x86_64-linux-gnu/libcrypto.so.3`: SHA-256 `8ae56f0a9481280a68c19f59809cd242a07a91ad7142944d21a878221992244b`.
- Both rounds recorded `libssl3t64:amd64 3.5.7-1~deb13u3`; the live r2 package-ownership check identifies that package as owner of both files, and OpenSSL reports 3.5.7. The observed file hashes agree across both containers. The full mapped-file hashes and complete installed-package inventory are retained, not merely the command-line version.
- `dpkg --verify libssl3t64` reported four missing documentation/lintian files in the slim image. That output is retained; it is not represented as a clean whole-package verification. No runtime-library mismatch was reported.

The separate 14 November Ubuntu process observation used host OpenSSL 3.0.13. This supplement does not retrospectively identify the libraries loaded by every original process or declare the original outcomes invalid. Host `libssl3t64` remained `3.0.13-0ubuntu3.16` after this test. The scope still excludes external KMS, HA/failover, repeated or WAL-key rotations, concurrency, cross-version restore and production data.

## Inspect the supplied evidence without Docker

`supplement-evidence-20261115.zip` has SHA-256 `2e45c24e0229b5dcd33140bebf5c98173a51c8acd249fb6d7ef7dee9919f412e`, 616455 bytes. It contains 424 explicitly allowlisted files plus `SUPPLEMENT_MANIFEST.json`. It excludes keys, credentials, PGDATA, backup repositories, software binaries and input archives. Three unrelated authentication-nonce fields per round were redacted by the original sanitizer. No outcome, payload or error was changed.

Place both ZIP files in your current directory, then verify before extracting into new directories:

```sh
set -euo pipefail
printf '%s\n' \
  'cc2fbd7bfeb53e182be666d3c6d3c8da4abe1588ea1b834823472c9cf738ad30  percona-pg-tde-recovery-path-lab-20261113.zip' \
  '2e45c24e0229b5dcd33140bebf5c98173a51c8acd249fb6d7ef7dee9919f412e  supplement-evidence-20261115.zip' \
  | sha256sum -c -
[ ! -e original ] && mkdir original
[ ! -e supplement ] && mkdir supplement
python3 -m zipfile -e percona-pg-tde-recovery-path-lab-20261113.zip original
python3 -m zipfile -e supplement-evidence-20261115.zip supplement
(cd original && sha256sum -c CHECKSUMS.sha256)
```

Then audit all exported hashes and both scientific results:

```sh
python3 - <<'PY'
import hashlib, json
from pathlib import Path
root = Path('supplement')
m = json.loads((root / 'SUPPLEMENT_MANIFEST.json').read_text())
for row in m['files']:
    data = (root / row['path']).read_bytes()
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']
print('Verified', len(m['files']), 'supplement files')
PY
python3 original/src/verify_recorded_evidence.py --runs-root supplement/r1/evidence/runs --rounds r1-matrix --control r1-clean
python3 original/src/verify_recorded_evidence.py --runs-root supplement/r2/evidence/runs --rounds r2-matrix --control r2-clean
```

The final `scripts/run_container.py` accepts `--root`; it was actually used for r2. The earlier hard-coded controller used for provisioning, timeout self-test and r1 is preserved at `records/run_container-r1.py`. Their hashes are `ee89dfedcc5be834148770bf37dbbe6932f68f155455e8fd3cf082e30b51a85d` and `df648ea26e2d693f1dadb4e086d88b52be2ab3c948021fabe88f8605ad08f042`, respectively. The installer, observer and packaged scientific runners were unchanged between rounds. Seven local guardrail regression tests also passed.

## Reader replay: from the original ZIP to a new runtime

Use a disposable Linux x86_64 Docker host and an ordinary host account with UID 1000, existing authorized `sudo -n docker` access, Python 3, curl, tar, and adequate private disk. The container account is also UID 1000. Do not run this on a production Docker engine. The fixed container names must not already exist; failures deliberately do not remove old containers or reuse old work directories. Do not add yourself to a privileged group or alter Docker socket permissions to make the instructions run.

The following commands use the extracted `supplement/scripts` and its recorded package inventory. Set `SUPPLEMENT` and `COMPANION` to the absolute paths of the extracted evidence directory and verified original companion ZIP. Only `ROOT` is a new local directory, so no recorded private image ID or Japan account path is needed. Use a simple absolute path with ASCII letters, digits, underscores and hyphens; no spaces, dots or shell metacharacters in `ROOT`.

```sh
set -euo pipefail
umask 077
SUPPLEMENT=/absolute/path/to/supplement
COMPANION=/absolute/path/to/percona-pg-tde-recovery-path-lab-20261113.zip
ROOT="$HOME/percona-clean-repro-20261115"
BASE=debian@sha256:7378260c0a098d27ac206225db5e7d92b8c7c84ea7afccc86eeb513756bbd392
[ "$(id -u)" = 1000 ]
[ ! -e "$ROOT" ]
mkdir "$ROOT"
mkdir "$ROOT/inputs" "$ROOT/scripts" "$ROOT/records"
cp "$SUPPLEMENT/scripts/"* "$ROOT/scripts/"
cp "$COMPANION" "$ROOT/inputs/companion.zip"
cd "$ROOT"
date -u > records/setup-start.txt
curl --fail --show-error --location --proto =https --proto-redir =https \
  --connect-timeout 20 --max-time 300 --output inputs/percona.tar.gz \
  https://downloads.percona.com/downloads/postgresql-distribution-18/18.7/binary/tarball/percona-postgresql-18.7-ssl3.5-linux-x86_64.tar.gz \
  2> records/tarball-download.log
printf '%s\n' \
  'cc2fbd7bfeb53e182be666d3c6d3c8da4abe1588ea1b834823472c9cf738ad30  inputs/companion.zip' \
  '992008f839865fc240848a8eb4c3e7ae76ecf221479bfd17f67a146611186300  inputs/percona.tar.gz' \
  | sha256sum -c -
sha256sum inputs/companion.zip inputs/percona.tar.gz > records/input-sha256.txt
timeout 300 sudo -n docker pull --platform linux/amd64 "$BASE" 2>&1 | tee records/base-image-pull.log
sudo -n docker image inspect "$BASE" > records/base-image-inspect.json
```

The tarball contains 14966 entries, with 13 component directories directly at its root. The installer uses Python's safe data extraction filter into a fresh `vendor/`, without stripping a top-level directory. It checks the original ZIP's checksums, all three pinned binary hashes, OpenSSL 3.5.x and unresolved `ldd` dependencies before allowing a database run.

First test the exact-CID timeout cleanup. A nonzero controller return is expected only for this self-test:

```sh
if python3 scripts/run_container.py --root "$ROOT" --phase timeout-selftest --deadline 2 \
    > records/timeout-selftest-controller.log 2>&1; then
  echo 'Unexpected self-test success' >&2; exit 1
fi
python3 - <<'PY'
import json
p = json.load(open('records/timeout-selftest-container.json'))
assert p['timed_out'] and not p['final_state']['Running'] and p['stop_returncode'] == 0
PY
python3 scripts/run_container.py --root "$ROOT" --phase provision --deadline 600
CID=$(python3 -c 'import json; print(json.load(open("records/provision-container.json"))["cid"])')
IMAGE=$(sudo -n docker commit "$CID" percona-clean-deps:20261115)
printf '%s\n' "$IMAGE" > records/dependency-image-id.txt
sudo -n docker image inspect "$IMAGE" > records/dependency-image-inspect.json
sudo -n docker cp "$CID":/tmp/package-lock.tsv - | tar -xOf - > records/package-lock.tsv
cmp "$SUPPLEMENT/records/package-lock.tsv" records/package-lock.tsv
```

Provisioning installs exactly `python3=3.13.5-1`, `openssl=3.5.7-1~deb13u3`, and `libreadline-dev=8.2-6` from the image's normal Debian repositories. The entire actual transitive/base package inventory is pinned by the final `cmp` against `records/package-lock.tsv`; stop on any difference. It includes Python 3.13.5-2+deb13u5 and libreadline8t64 8.2-6. If exact packages are no longer available, report that blocker rather than silently substituting a different environment. A newly committed local image can have a different image ID because commit metadata differ; always derive and record the ID as above.

Now use that newly created image twice. Each command creates a new work directory and container, independently verifies and extracts both inputs, runs the unmodified scientific entry points, samples mapped libraries, audits results, exports only the allowlist and runs the original nonce sanitizer. A 1200-second whole-container deadline stops the exact owned container on expiry; normal completion also records the final stopped state.

```sh
cp scripts/run_container.py records/run_container-r1.py
sha256sum records/run_container-r1.py > records/run_container-r1.sha256
python3 scripts/run_container.py --root "$ROOT" --phase r1 --image "$IMAGE" --deadline 1200
python3 scripts/run_container.py --root "$ROOT" --phase r2 --image "$IMAGE" --deadline 1200
python3 - <<'PY'
import json
for phase in ['provision', 'timeout-selftest', 'r1', 'r2']:
    p = json.load(open('records/' + phase + '-container.json'))
    assert not p['final_state']['Running']
    if phase != 'timeout-selftest':
        assert p['controller_returncode'] == 0 and p['final_state']['ExitCode'] == 0
print('All owned containers stopped')
PY
python3 scripts/export_supplement.py --root "$ROOT" --output "$ROOT/new-supplement-evidence.zip"
```

Do not share `r1/lab` or `r2/lab`: they retain synthetic key files, generated repository credentials, database files and backup repositories. The export checks every inner manifest and scans all export candidates for both generated repository passphrases. Retain failed logs and incomplete directories; do not reinterpret a partially finished run as a pass or overwrite evidence to retry.

## Primary sources and boundaries

- [Percona tarball installation and OpenSSL variants](https://docs.percona.com/postgresql/18/tarball.html). The documentation also warns that tarballs do not manage dependency safety; this disposable test is not a production recommendation.
- [Official Debian image amd64 digest and artifact provenance](https://raw.githubusercontent.com/docker-library/repo-info/master/repos/debian/remote/trixie-slim.md).
- [Debian 13 libssl3t64 package](https://packages.debian.org/trixie/libssl3t64).

All experiment data are synthetic. Model assistance was used for implementation, investigation and writing; execution and audits were automated. New runtime observations are limited samples, not evidence that every short-lived process was captured. This supplement does not expand the original scientific claims.

## Bundle layout and optional guardrail check

This outer bundle contains the unchanged evidence ZIP, the reader instructions, and a copy of the final wrapper scripts with their seven-test safety regression suite. To rerun only these offline guardrail tests, from this outer bundle directory run `python3 scripts/test_safety.py`. No Docker, database or network is used by that suite. The scripts other than the test file match the final scripts inside the evidence ZIP byte for byte. This packaging step does not change any recorded experiment.
