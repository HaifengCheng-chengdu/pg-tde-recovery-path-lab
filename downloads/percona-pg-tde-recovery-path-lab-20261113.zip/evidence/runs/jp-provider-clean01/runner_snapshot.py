#!/usr/bin/env python3
"""Disposable local pg_tde recovery lab. No TCP, real data, or external KMS.

All databases, key files and repositories are newly created below a new run dir.
Only copies of synthetic keys are withheld; originals are never destroyed.
Do not point this script at an existing database or backup repository.
"""
import argparse, hashlib, json, os, pathlib, pwd, secrets, shutil, subprocess, time

ROOT = pathlib.Path(__file__).resolve().parents[1]
PGBIN = ROOT / 'vendor/percona-postgresql18/bin'
BACKREST = ROOT / 'vendor/percona-pgbackrest/bin/pgbackrest'
ROLE = pwd.getpwuid(os.getuid()).pw_name
ENV = {'LC_ALL':'C','TZ':'UTC','PGCONNECT_TIMEOUT':'3',
       'USER':ROLE,'LOGNAME':ROLE,'HOME':str(ROOT/'artifacts/empty-home'),
       'PATH':str(PGBIN)+':'+str(BACKREST.parent)+':/usr/bin:/bin'}

class Lab:
    def __init__(self, name):
        self.root = ROOT / 'runs' / name
        self.root.mkdir(mode=0o700)  # refuse reuse
        (ROOT/'artifacts/empty-home').mkdir(mode=0o700,exist_ok=True)
        self.sock = pathlib.Path('/tmp') / ('tde-' + secrets.token_hex(5))
        self.sock.mkdir(mode=0o700)
        for p in ['logs', 'repo', 'keys-original', 'keys-active', 'lock', 'spool']:
            (self.root / p).mkdir(mode=0o700)
        self.source = self.root / 'source'
        self.cfg = self.root / 'pgbackrest.conf'
        self.port = '56981'
        self.seq = 0
        self.events = []
        self.live = set()
        self.password = secrets.token_urlsafe(36)
        snapshot=pathlib.Path(__file__).read_bytes()
        (self.root/'runner_snapshot.py').write_bytes(snapshot)
        (self.root/'runner_sha256.txt').write_text(hashlib.sha256(snapshot).hexdigest()+'\n')

    def run(self, cmd, label, check=True, timeout=90, data=None, cwd=None):
        self.seq += 1
        cmd = [str(x) for x in cmd]
        start = time.time()
        timed_out=False
        try:
            r = subprocess.run(cmd, input=data, text=True, capture_output=True,
                               env=ENV, timeout=timeout, cwd=cwd)
        except subprocess.TimeoutExpired as exc:
            timed_out=True
            def decoded(value):
                return value.decode(errors='replace') if isinstance(value,bytes) else (value or '')
            r=subprocess.CompletedProcess(cmd,124,decoded(exc.stdout),decoded(exc.stderr)+'\nCONTROL CLIENT TIMED OUT\n')
        # No command arguments contain key material or repository passphrases.
        log = self.root / 'logs' / f'{self.seq:03d}-{label}.log'
        log.write_text('$ ' + ' '.join(cmd) + '\n' + r.stdout + r.stderr)
        e = dict(label=label, started_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)), returncode=r.returncode, timed_out=timed_out, elapsed=round(time.time()-start,3), log=str(log.relative_to(self.root)))
        self.events.append(e)
        (self.root / 'events.json').write_text(json.dumps(self.events,indent=2))
        if check and r.returncode:
            raise RuntimeError(f'{label}: rc={r.returncode}; see {log}')
        return r

    def sql(self, sql, label, check=True):
        return self.run([PGBIN/'psql','-X','-A','-t','-v','ON_ERROR_STOP=1',
                         '-U',ROLE,'-h',self.sock,'-p',self.port,'-d','postgres','-c',sql],label,check)

    def control(self, path, action, label, check=True):
        if action=='start': self.live.add(path)  # tracked even if the control client times out
        args=[PGBIN/'pg_ctl','-D',path,'-w','-t','25']
        if action=='start': args += ['-l',self.root/'logs'/f'{label}-server.log','start']
        else: args += ['-m','fast','stop']
        r=self.run(args,label,False,timeout=35)
        running=(path/'postmaster.pid').exists()
        if action=='start' and (r.returncode==0 or running): self.live.add(path)
        if action=='stop':
            if running:
                raise RuntimeError(f'{label}: stop not confirmed; refusing to change keys or continue')
            self.live.discard(path)
        if check and r.returncode:
            raise RuntimeError(f'{label}: rc={r.returncode}')
        return r

    def br(self, args, label, check=True):
        return self.run([BACKREST,'--config='+str(self.cfg),'--stanza=lab']+args,label,check,timeout=180)

    def key_state(self, expected, label):
        key=self.sql('SELECT * FROM pg_tde_key_info();',label+'-database-key').stdout.strip()
        wal=self.sql('SELECT * FROM pg_tde_server_key_info();',label+'-server-key').stdout.strip()
        if not key.startswith(expected+'|') or not wal.startswith('W0|wal_provider|'):
            raise RuntimeError('unexpected database/server principal key identifiers')
        return dict(database_key=key.split('|')[:3],server_key=wal.split('|')[:3])

    def digest(self, label):
        r=self.sql("COPY (SELECT id, epoch, payload FROM ledger ORDER BY id) TO STDOUT WITH CSV",label)
        digest=hashlib.sha256(r.stdout.encode()).hexdigest()
        state=self.sql("SELECT count(*) FROM ledger; SELECT a.amname FROM pg_class c JOIN pg_am a ON c.relam=a.oid WHERE c.oid='ledger'::regclass; SELECT pg_tde_is_encrypted('ledger');",label+'-state').stdout.strip().splitlines()
        if state[1:]!=['tde_heap','t']:
            raise RuntimeError('ledger is not reported as encrypted tde_heap')
        index=self.sql("SET enable_seqscan=off; SELECT count(*),sum(id),sum(epoch) FROM ledger WHERE id BETWEEN 71 AND 193; SELECT pg_tde_is_encrypted('ledger'); SELECT phase FROM marker;",label+'-index').stdout.strip()
        plan_text=self.sql("SET enable_seqscan=off; EXPLAIN (FORMAT JSON) SELECT count(*),sum(id),sum(epoch) FROM ledger WHERE id BETWEEN 71 AND 193;",label+'-plan').stdout
        plan=json.loads(plan_text[plan_text.index('['):])
        def nodes(node):
            found=[node['Node Type']]
            for child in node.get('Plans',[]):found.extend(nodes(child))
            return found
        node_types=nodes(plan[0]['Plan'])
        if not any(n in ['Index Scan','Index Only Scan','Bitmap Index Scan'] for n in node_types):
            raise RuntimeError(f'{label}: no index traversal in plan {node_types}')
        return dict(sha256=digest, bytes=len(r.stdout.encode()), rows=int(state[0]), access_method=state[1], encrypted=True, index=index, index_plan=node_types)

    def backup(self,label):
        self.br(['--type=full','backup'],label)
        info=json.loads(self.br(['--output=json','info'],label+'-info').stdout)
        return info[0]['backup'][-1]['label']

    def switch(self,label):
        f=self.sql("SELECT pg_walfile_name(pg_current_wal_lsn());",label+'-segment').stdout.strip()
        self.sql('SELECT pg_switch_wal();',label+'-switch')
        deadline=time.monotonic()+60
        while time.monotonic()<deadline:
            if (self.source/'pg_wal/archive_status'/f'{f}.done').exists(): return f
            time.sleep(.1)
        raise RuntimeError(f'archiving timeout: {f}')

    def setup(self):
        self.run([PGBIN/'postgres','--version'],'version-postgres')
        self.run([BACKREST,'version'],'version-pgbackrest')
        self.run([PGBIN/'pg_tde_archive_decrypt','--version'],'version-tde')
        self.run([PGBIN/'initdb','-D',self.source,'--no-locale','--encoding=UTF8','--auth-local=trust','--auth-host=reject'],'initdb')
        common=f"\nlisten_addresses=''\nport={self.port}\nunix_socket_directories='{self.sock}'\nunix_socket_permissions=0700\nshared_preload_libraries='pg_tde'\nshared_buffers='32MB'\nmax_connections=15\nwal_level=replica\nmax_wal_senders=3\nlogging_collector=off\nlog_min_messages=info\n"
        with (self.source/'postgresql.conf').open('a') as f:f.write(common)
        self.cfg.write_text(f'''[lab]
pg1-path={self.source}
pg1-socket-path={self.sock}
pg1-port={self.port}
pg1-user={ROLE}

[global]
repo1-path={self.root/'repo'}
repo1-retention-full=8
repo1-cipher-type=aes-256-cbc
repo1-cipher-pass={self.password}
compress-type=none
archive-async=n
archive-header-check=n
checksum-page=n
start-fast=y
process-max=1
lock-path={self.root/'lock'}
spool-path={self.root/'spool'}
log-path={self.root/'logs'}
log-level-console=info
log-level-file=off
''')
        self.cfg.chmod(0o600)
        self.control(self.source,'start','bootstrap-start')
        self.sql(f"""
CREATE EXTENSION pg_tde;
SELECT pg_tde_add_global_key_provider_file('wal_provider','{self.root}/keys-active/w0.per');
SELECT pg_tde_create_key_using_global_key_provider('W0','wal_provider');
SELECT pg_tde_set_server_key_using_global_key_provider('W0','wal_provider');
SELECT pg_tde_add_database_key_provider_file('p0','{self.root}/keys-active/k0.per');
SELECT pg_tde_add_database_key_provider_file('p1','{self.root}/keys-active/k1.per');
SELECT pg_tde_create_key_using_database_key_provider('K0','p0');
SELECT pg_tde_create_key_using_database_key_provider('K1','p1');
SELECT pg_tde_set_key_using_database_key_provider('K0','p0');
SELECT version(); SELECT extversion FROM pg_extension WHERE extname='pg_tde';
SELECT * FROM pg_tde_key_info(); SELECT * FROM pg_tde_server_key_info();
""",'configure-keys')
        self.control(self.source,'stop','bootstrap-stop')
        archive=f'{PGBIN}/pg_tde_archive_decrypt %f %p "{BACKREST} --config={self.cfg} --stanza=lab archive-push %%p"'
        with (self.source/'postgresql.conf').open('a') as f:
            f.write(f"\npg_tde.wal_encrypt=on\narchive_mode=on\narchive_command='{archive}'\n")
        self.control(self.source,'start','encrypted-start')
        tde_version=self.sql('SELECT pg_tde_version();','tde-runtime-version').stdout.strip()
        self.sql("""CREATE TABLE ledger(id integer PRIMARY KEY,epoch integer NOT NULL,payload text NOT NULL) USING tde_heap;
ALTER TABLE ledger ALTER COLUMN payload SET STORAGE EXTERNAL;
INSERT INTO ledger SELECT i,0,repeat(md5('synthetic-row-'||i::text),128) FROM generate_series(1,256) i;
CREATE TABLE marker(phase text NOT NULL); INSERT INTO marker VALUES('baseline');
CHECKPOINT;
SHOW pg_tde.wal_encrypt; SELECT pg_tde_is_encrypted('ledger');
""",'dataset')
        self.br(['stanza-create'],'stanza-create')
        self.br(['check'],'repository-check')
        f0=self.backup('backup-f0')
        self.sql("UPDATE ledger SET epoch=1,payload=payload||'-before' WHERE id%7=0; UPDATE marker SET phase='before';",'before-writes')
        before=self.digest('before-digest')
        if before['rows']!=256: raise RuntimeError('unexpected pre-rotation source row count')
        before_keys=self.key_state('K0','before-key-state')
        lsn0=self.sql("SELECT pg_create_restore_point('before_rotation');",'before-target').stdout.strip()
        self.switch('before-target')
        self.sql("SELECT pg_tde_set_key_using_database_key_provider('K1','p1'); SELECT * FROM pg_tde_key_info();",'rotate-db-key')
        self.sql("UPDATE ledger SET epoch=2,payload=payload||'-after' WHERE id%5=0; INSERT INTO ledger SELECT i,2,repeat(md5('new-'||i::text),128) FROM generate_series(257,272) i; UPDATE marker SET phase='after'; CHECKPOINT;",'after-writes')
        f1=self.backup('backup-f1')
        after=self.digest('after-digest')
        if after['rows']!=272: raise RuntimeError('unexpected post-rotation source row count')
        after_keys=self.key_state('K1','after-key-state')
        lsn1=self.sql("SELECT pg_create_restore_point('after_rotation');",'after-target').stdout.strip()
        self.switch('after-target')
        db_oid=int(self.sql("SELECT oid FROM pg_database WHERE datname=current_database();",'database-oid').stdout.strip())
        self.control(self.source,'stop','source-stop')
        for p in (self.root/'keys-active').iterdir():
            shutil.copy2(p,self.root/'keys-original'/p.name)
        self.meta=dict(pg_tde_version=tde_version,db_oid=db_oid,backups=dict(F0=f0,F1=f1),expected=dict(before=before,after=after),targets=dict(before=lsn0,after=lsn1),key_states=dict(before=before_keys,after=after_keys))
        (self.root/'metadata.json').write_text(json.dumps(self.meta,indent=2))

    def keyset(self,keys):
        # Only remove replaceable copies, not the unique original key files.
        # This models unavailable key-bearing files, not a KMS key-not-found response.
        if self.live: raise RuntimeError('refusing key changes while any lab server might be running')
        for key in ['k0','k1','w0']:
            dst=self.root/'keys-active'/f'{key}.per'
            if key in keys: shutil.copy2(self.root/'keys-original'/dst.name,dst)
            elif dst.exists(): dst.unlink()

    def case(self,name,backup,target,keys,move_key=False,repair_provider=False):
        self.keyset(keys+['w0'])
        relocated=self.root/'keys-active/k0-relocated.per'
        if move_key:
            (self.root/'keys-active/k0.per').replace(relocated)
        result=dict(case=name,backup=backup,target=target,keys=keys)
        result['verify_rc']=self.br(['verify'],name+'-verify',False).returncode
        path=self.root/('restore-'+name)
        restore=f'{PGBIN}/pg_tde_restore_encrypt %f %p "{BACKREST} --config={self.cfg} --stanza=lab --pg1-path={path} archive-get %%f %%p"'
        rr=self.br(['--pg1-path='+str(path),'--set='+self.meta['backups'][backup],
                    '--type=name','--target='+target+'_rotation','--target-action=promote',
                    '--archive-mode=off','--recovery-option=restore_command='+restore,'restore'],name+'-restore',False)
        result['restore_rc']=rr.returncode
        if rr.returncode==0 and repair_provider:
            fix=self.run([PGBIN/'pg_tde_change_key_provider','-D',path,str(self.meta['db_oid']),'p0','file',relocated],name+'-offline-provider-repair',False)
            result['repair_rc']=fix.returncode
            if fix.returncode:
                result['stage']='offline-provider-guard'
                result['repair_error']=fix.stderr.strip()
                result['guard_matches']='cluster must be shut down' in fix.stderr
                self.run([PGBIN/'pg_controldata',path],name+'-control-data')
                return result
        if rr.returncode:
            result['stage']='restore';return result
        start=self.control(path,'start',name+'-start',False)
        result['start_rc']=start.returncode
        if start.returncode:
            result['stage']='startup/replay'
            log=(self.root/'logs'/f'{name}-start-server.log').read_text()
            result['key_errors']=[l for l in log.splitlines() if 'FATAL:' in l and ('key "' in l or 'principal key' in l)]
            result['redo_context']=[l for l in log.splitlines() if 'CONTEXT:' in l and 'WAL redo' in l]
            if result['key_errors'] and result['redo_context']:
                result['stage']='key-unavailable-during-replay'
            self.control(path,'stop',name+'-stop-if-running',False)
            return result
        try:
            deadline=time.monotonic()+30
            while True:
                r=self.sql('SELECT pg_is_in_recovery(); SELECT phase FROM marker;',name+'-target',False)
                if r.returncode==0 and r.stdout.strip()==f'f\n{target}': break
                if not (path/'postmaster.pid').exists() or time.monotonic()>deadline: break
                time.sleep(.2)
            result['target_rc']=r.returncode
            result['target_output']=r.stdout.strip()
            if r.returncode or r.stdout.strip()!=f'f\n{target}':
                result['stage']='target-validation'
                log=(self.root/'logs'/f'{name}-start-server.log').read_text()
                result['key_errors']=[l for l in log.splitlines() if 'FATAL:' in l and ('key "' in l or 'principal key' in l)]
                result['redo_context']=[l for l in log.splitlines() if 'CONTEXT:' in l and 'WAL redo' in l]
                if result['key_errors'] and result['redo_context']:
                    result['stage']='key-unavailable-during-replay'
                return result
            server_log=(self.root/'logs'/f'{name}-start-server.log').read_text()
            result['named_target_in_log']=f'recovery stopping at restore point "{target}_rotation"' in server_log
            if not result['named_target_in_log']:
                result['stage']='named-target-not-proven';return result
            replay=self.sql('SELECT pg_last_wal_replay_lsn();',name+'-target-lsn').stdout.strip()
            result['replay_lsn']=replay
            result['expected_target_lsn']=self.meta['targets'][target]
            if replay!=self.meta['targets'][target]:
                result['stage']='target-lsn-mismatch';return result
            try:
                got=self.digest(name+'-digest')
                result['digest']=got
                result['matches_expected']=all(got[k]==self.meta['expected'][target][k] for k in ['sha256','bytes','rows','access_method','encrypted','index'])
                result['stage']='pass' if result['matches_expected'] else 'data-mismatch'
            except RuntimeError:
                result['stage']='encrypted-data-read'
                result['key_errors']=[]
                for lf in (self.root/'logs').glob('*-'+name+'-digest*.log'):
                    result['key_errors'].extend(l for l in lf.read_text().splitlines() if 'ERROR:' in l and ('key "' in l or 'principal key' in l))
        finally:
            self.control(path,'stop',name+'-stop',False)
        return result

    def matrix(self):
        results=[]
        for route,backup,target in [('old_before','F0','before'),('old_after','F0','after'),('new_after','F1','after')]:
            for group,keys in [('both',['k0','k1']),('k0',['k0']),('k1',['k1'])]:
                r=self.case(route+'_'+group,backup,target,keys)
                results.append(r)
                (self.root/'results.json').write_text(json.dumps(results,indent=2))
                print(json.dumps(r),flush=True)
        for name,repair in [('provider_path_missing',False),('provider_path_repaired',True)]:
            r=self.case(name,'F0','before',['k0','k1'],move_key=True,repair_provider=repair)
            results.append(r)
            (self.root/'results.json').write_text(json.dumps(results,indent=2))
            print(json.dumps(r),flush=True)
        expected_pass={'old_before_both','old_before_k0','old_after_both','new_after_both','new_after_k1'}
        expected_fail={'old_before_k1':'K0','old_after_k0':'K1','old_after_k1':'K0','new_after_k0':'K1','provider_path_missing':'K0'}
        for r in results:
            if r['case'] in expected_pass:
                r['expected_outcome_matches']=r['stage']=='pass'
            elif r['case']=='provider_path_repaired':
                r['expected_outcome_matches']=r.get('guard_matches',False)
            else:
                key=expected_fail[r['case']]
                r['expected_outcome_matches']=r['stage'] in ['key-unavailable-during-replay','encrypted-data-read'] and any('"'+key+'"' in e for e in r.get('key_errors',[]))
        (self.root/'results.json').write_text(json.dumps(results,indent=2))
        controls=[r for r in results if r['case'] in expected_pass]
        valid=all(r['stage']=='pass' for r in controls)
        valid=valid and all(r['verify_rc']==0 and r['restore_rc']==0 and r['expected_outcome_matches'] for r in results)
        summary=dict(positive_controls_pass=valid, observations=len(results),
                     note='Expected outcomes derived from documented key dependencies and 2.2.2 redo source; negative cases require a matching key identifier and WAL redo context. Repetition and independent review remain separate gates.')
        (self.root/'summary.json').write_text(json.dumps(summary,indent=2))
        if not valid: raise RuntimeError('matrix positive controls or repository stages failed; not an interpretable experiment')

    def cleanup(self):
        for path in list(self.live):
            self.control(path,'stop','cleanup-stop',False)
        try:self.sock.rmdir()
        except OSError:pass

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--name',required=True)
    args=ap.parse_args()
    if not args.name.replace('-','').replace('_','').isalnum():ap.error('simple run name required')
    lab=Lab(args.name)
    try:
        lab.setup();lab.matrix()
    finally:lab.cleanup()
