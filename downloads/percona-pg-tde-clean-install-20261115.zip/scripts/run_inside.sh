#!/bin/bash
set -euo pipefail
umask 077
name="${1:?run name required}"
[[ "$name" =~ ^r[12]$ ]] || exit 64
python3 /scripts/clean_install.py --companion /inputs/companion.zip --tarball /inputs/percona.tar.gz --lab /work/lab --report /work/install.json
python3 /scripts/run_observed.py --lab /work/lab --round "${name}-matrix" --control "${name}-clean" --report /work/runtime-libraries.json
cd /work/lab
python3 src/verify_recorded_evidence.py --runs-root runs --rounds "${name}-matrix" --control "${name}-clean" --allow-unmanifested > /work/private-audit.json
python3 src/export_evidence.py --runs "${name}-matrix" "${name}-clean" --output private-staging.zip
python3 src/prepare_public_evidence.py --input artifacts/private-staging.zip --output /work/evidence
python3 src/verify_recorded_evidence.py --runs-root /work/evidence/runs --rounds "${name}-matrix" --control "${name}-clean" > /work/evidence-audit.json
cat /work/evidence-audit.json
