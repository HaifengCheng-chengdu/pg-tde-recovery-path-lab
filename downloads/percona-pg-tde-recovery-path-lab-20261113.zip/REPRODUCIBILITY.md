# Reproduce the lab

## Scope and prerequisites

Use a disposable non-root Linux x86_64 environment with Python 3, glibc, adequate private local disk, `/dev/shm`, and permission to create Unix-domain sockets. The recorded execution used Ubuntu 24.04.5 LTS and the exact binaries below. The host `openssl` command reported 3.0.13; this is not proof of which library each database process loaded. A fresh-host portability test and dynamic-linker inventory were not completed.

The main runner was executed under a one-CPU, 1 GiB systemd user-unit limit. Keep the session attached: a first development attempt was terminated when its SSH/user session ended. Do not infer performance, memory requirements or a production sizing recommendation from this tiny lab. Allow several GiB of disk for the private backups, WAL and restored copies; the experiment did not benchmark peak disk requirements.

Use a simple working path without spaces or shell metacharacters because the runner constructs archive/restore shell commands. Do not use production directories, real KMS keys or real credentials. Each run name must be fresh. Do not force-delete a run directory while its PostgreSQL instance might be active.

## Pin and verify the distribution

Official archive:

https://downloads.percona.com/downloads/postgresql-distribution-18/18.7/binary/tarball/percona-postgresql-18.7-ssl3.5-linux-x86_64.tar.gz

Archive SHA-256:

`992008f839865fc240848a8eb4c3e7ae76ecf221479bfd17f67a146611186300`

Read the current [official tarball instructions](https://docs.percona.com/postgresql/18/tarball.html) and [18.7.1 release notes](https://docs.percona.com/postgresql/18/release-notes/release-notes-v18.7.1.html) for platform requirements. Do not silently substitute a newer archive if this one is unavailable.

After downloading, verify the hash and inspect `tar -tzf` before extracting into a new private directory. Arrange the extracted components under `vendor/` so these paths exist. Do not assume a tarball top-level directory name or strip count; the original extraction command was not preserved.

- `vendor/percona-postgresql18/bin/`: postgres, initdb, psql, pg_ctl, pg_controldata, pg_tde_archive_decrypt, pg_tde_restore_encrypt, pg_tde_change_key_provider.
- `vendor/percona-postgresql18/lib/pg_tde.so`.
- `vendor/percona-pgbackrest/bin/pgbackrest`.

Verify at least these exact binary hashes:

```text
93dfcfecbf193fbff3ffa5b9c4cfe11f26f0c18a29ab16dc3b09d70c223758f3  vendor/percona-postgresql18/bin/postgres
1a1b3158524058d0e0eb61e6448605d67f3c5693623f1a46f121cc597185ad8d  vendor/percona-postgresql18/lib/pg_tde.so
7bf333939cc7892caf4aef8cba3858dd7bb85df02bfa2f71cf00b990e7591e2f  vendor/percona-pgbackrest/bin/pgbackrest
```

The expected runtime labels are PostgreSQL 18.7 / Percona Server 18.7.1, pg_tde 2.2.2 and pgBackRest 2.60.0. The runner records `SELECT pg_tde_version()`; SQL extension version 2.2 and the wrapper's PostgreSQL-style `--version` output are not substitutes for that patch-version check.

## Execute fresh rounds

From this companion's root, create the empty parent directories, then run sequentially:

```sh
mkdir -p runs artifacts
for n in r1 r2 r3; do
  python3 src/run_matrix.py --name "$n" || exit 1
done
python3 src/run_clean_provider_control.py --base r1 --name clean1
python3 src/verify_recorded_evidence.py --runs-root runs --rounds r1 r2 r3 --control clean1 --allow-unmanifested
```

The explicit `--allow-unmanifested` flag is only for newly generated private runs before export. Auditing the supplied evidence requires its manifest by default; a missing manifest is an error.

The control needs the **private** completed `r1` directory, specifically its cleanly stopped F1/K1 recovery and synthetic keys. The sanitized evidence package intentionally cannot supply those private fixtures. Run the matrix locally first; do not point the control at `evidence/runs/`.

The matrix's raw case name `provider_path_repaired` is a historical label for an **attempted** repair on a fresh online-backup restore. It is expected to record the CLI's clean-shutdown guard refusal, not successful repair. The successful repair is the separate `clean1` control.

Each main run creates its own source, two full backups, generated keys, repository passphrase and restore directories. The source is stopped before key availability is altered. Both p0/p1 providers and K0/K1 keys exist before F0; only the active database principal key changes at rotation. W0 and repository credentials remain available. Server instances are stopped between cases. Original synthetic key files are retained; only replaceable active copies are withheld.

## Export a new run safely

```sh
python3 src/export_evidence.py --runs r1 r2 r3 clean1 --output private-staging.zip
python3 src/prepare_public_evidence.py --input artifacts/private-staging.zip --output public-evidence
```

The first output is private staging, not a release artifact. The second validates every original manifest hash, redacts only the unrelated nonce field, emits a new hash manifest and refuses to overwrite a destination. Review and secret-scan any newly generated evidence before sharing. The original tested exporter records absolute local paths; review those for your own environment too.

## What is reproducible, and what is not claimed

Three fresh database rounds used the same frozen main runner on one host. Two rounds were independently invoked and reviewed, but this was not a second operating system or a newly provisioned machine. LSNs, backup labels, timestamps, PIDs and generated key material can differ; compare each recovery with its own source target. Data hashes should remain identical for the fixed fixture. EXPLAIN plan node types are recorded, but no EXPLAIN ANALYZE execution trace is claimed.
