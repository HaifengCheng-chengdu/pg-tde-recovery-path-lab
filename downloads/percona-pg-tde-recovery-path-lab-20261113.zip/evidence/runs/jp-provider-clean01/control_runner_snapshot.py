#!/usr/bin/env python3
"""Separate control: relocate provider only after completed recovery and clean stop."""
import argparse, hashlib, json, pathlib, shutil
from run_matrix import Lab, PGBIN, ROOT

def main(base_name, name):
    base=ROOT/'runs'/base_name
    meta=json.loads((base/'metadata.json').read_text())
    lab=Lab(name)
    (lab.root/'control_runner_snapshot.py').write_bytes(pathlib.Path(__file__).read_bytes())
    outcome={'control':'provider relocation after completed PITR and clean shutdown','base_run':base_name}
    try:
        shutil.copytree(base/'restore-new_after_k1',lab.source)
        with (lab.source/'postgresql.conf').open('a') as f:
            f.write(f"\nlisten_addresses=''\nport={lab.port}\nunix_socket_directories='{lab.sock}'\narchive_mode=off\n")
        for key in ['k1','w0']:
            shutil.copy2(base/'keys-original'/f'{key}.per',lab.root/'keys-original'/f'{key}.per')
            shutil.copy2(base/'keys-original'/f'{key}.per',lab.root/'keys-active'/f'{key}.per')
        lab.run([PGBIN/'pg_controldata',lab.source],'initial-clean-control-data')
        lab.run([PGBIN/'pg_tde_change_key_provider','-D',lab.source,str(meta['db_oid']),'p1','file',lab.root/'keys-active/k1.per'],'bind-isolated-db-provider')
        lab.run([PGBIN/'pg_tde_change_key_provider','-D',lab.source,'1664','wal_provider','file',lab.root/'keys-active/w0.per'],'bind-isolated-wal-provider')
        lab.control(lab.source,'start','baseline-start')
        before=lab.digest('baseline')
        lab.control(lab.source,'stop','baseline-stop')
        (lab.root/'keys-active/k1.per').replace(lab.root/'keys-active/k1-relocated.per')
        lab.control(lab.source,'start','missing-path-start')
        failure=lab.sql('SELECT count(payload) FROM ledger;','missing-path-read',False)
        outcome['missing_path_rc']=failure.returncode
        outcome['missing_path_error']=failure.stderr.strip()
        outcome['failure_matches']=failure.returncode!=0 and 'K1' in failure.stderr and 'key' in failure.stderr
        lab.control(lab.source,'stop','missing-path-clean-stop')
        lab.run([PGBIN/'pg_controldata',lab.source],'before-offline-fix-control-data')
        repair=lab.run([PGBIN/'pg_tde_change_key_provider','-D',lab.source,str(meta['db_oid']),'p1','file',lab.root/'keys-active/k1-relocated.per'],'offline-provider-fix')
        outcome['repair_rc']=repair.returncode
        lab.control(lab.source,'start','repaired-start')
        after=lab.digest('repaired')
        lab.control(lab.source,'stop','repaired-stop')
        fields=['sha256','bytes','rows','access_method','encrypted','index']
        outcome['baseline_matches_source']=all(before[k]==meta['expected']['after'][k] for k in fields)
        outcome['repair_matches_source']=all(after[k]==meta['expected']['after'][k] for k in fields)
        outcome['digest']=after
        outcome['pass']=outcome['failure_matches'] and outcome['baseline_matches_source'] and outcome['repair_matches_source'] and repair.returncode==0
        (lab.root/'results.json').write_text(json.dumps(outcome,indent=2))
        print(json.dumps(outcome),flush=True)
        if not outcome['pass']: raise RuntimeError('clean-shutdown provider control failed')
    finally: lab.cleanup()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',required=True);ap.add_argument('--name',required=True)
    a=ap.parse_args();main(a.base,a.name)
