# pg_tde recovery-path key matrix

Companion to **Which Keys Does a pg_tde Restore Need? A Nine-Case Rotation Lab**, by Haifeng Cheng.

This is a publication candidate, not a claim of editorial acceptance. The experiment ran on 13 November 2026. Model assistance was used for research, implementation and writing; the synthetic experiment and validation were automated. No production data or incident is represented.

## Start here

- `article.md`: the English article.
- `RESULTS.md`: measured matrix, identifiers, exact data hashes and evidence map.
- `REPRODUCIBILITY.md`: pinned installation inputs and executable entry points.
- `CLAIMS_AND_LIMITS.md`: what the evidence does and does not establish.
- `COMPARISON.md`: concrete comparison with existing published work.
- `DEVELOPMENT_HISTORY.md`: successful and unsuccessful development stages, without fabricated commit history.
- `PROVENANCE.json`: software/runtime and experiment provenance.
- `src/run_matrix.py`: exact frozen runner used for all three final rounds.
- `src/run_clean_provider_control.py`: separately tested clean-shutdown provider relocation control.
- `src/verify_recorded_evidence.py`: offline auditor of the recorded evidence, including full raw CSV outputs.
- `evidence/`: sanitized original command logs, metadata, per-run script snapshots and checksums.

## Audit without running a database

From this directory:

```sh
sha256sum -c CHECKSUMS.sha256
python3 src/verify_recorded_evidence.py --runs-root evidence/runs --rounds jp-round02 jp-round03-review jp-round04-review --control jp-provider-clean01
```

The recorded outcome is 27 core recovery cases: 15 complete recoveries and 12 causal missing-key failures, plus three missing-provider-path failures, three fresh-restore CLI guard refusals, and one separate successful clean-shutdown relocation control. Each core case's repository verify and file restore returned zero. The nine cases per round shared that round's repository.

The auditor checks 514 evidence-file hashes and reconstructs the complete CSV hashes from 23 raw command outputs. It does not rerun PostgreSQL. Fresh execution is described separately below.

## Safety and export boundary

Use a disposable non-root Linux account, synthetic data and newly generated test keys only. The runner binds no TCP listener; it uses a private Unix-socket directory with local trust authentication and host authentication rejected. It never uses external KMS services. Keep the execution session alive until it finishes.

Do not publish `runs/` wholesale. It contains key files, generated repository credentials, database files and the encrypted backup repository. Only the explicitly allowlisted evidence is in this package. Five unrelated `Mock authentication nonce` fields were redacted from pg_controldata output; the evidence manifest records each changed path and both original and sanitized hashes. No outcome, timestamp, LSN, payload or error message was changed.

`src/export_evidence.py` is the original tested *private staging* exporter. It excludes configurations/key files/PGDATA/repositories and checks for generated repository passphrases, but does not redact pg_controldata's nonce field. Do not publish its output directly. `src/prepare_public_evidence.py` performs the documented second-stage sanitation.

No software binaries, credentials, backup repositories or third-party source-code copies are distributed here. Source references are links to their original publishers. No license terms are asserted on the author's behalf.
