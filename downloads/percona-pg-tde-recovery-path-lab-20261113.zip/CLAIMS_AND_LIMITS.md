# Claims and limits

## Supported by the recorded experiment

1. For this pg_tde 2.2.2 fixture, F0→before needs K0, F0→after needs K0 and K1, and F1→after succeeds with K1 alone. All other required keys/credentials were retained.
2. Repository verification and file restore success did not establish successful database recovery or encrypted data readability.
3. The missing-K1 F0→after error occurred in the same process as the immediately following pg_tde/ROTATE_PRINCIPAL_KEY redo context. The version-matched source explains the old/new key dependency.
4. A fresh physical restore could have no live postmaster while pg_control still recorded `in production`, causing the offline provider-edit tool to refuse it.
5. Provider relocation worked in a separate instance after completed PITR and clean shutdown.
6. Three fresh rounds were internally consistent, including exact source-target LSN equality and full payload checks, not just row counts.

## Important experimental conditions

Both database providers and keys existed before F0. Rotation changed the active database principal key from K0/p0 to K1/p1, so it also changed provider identity. This does not test arbitrary same-provider versioning. File unavailability is not a complete simulation of KMS denial, revocation, deletion, latency or failover.

The fixture's source verification read after F1 generated page-maintenance WAL. Its PRUNE_ON_ACCESS failure phase must not be generalised to every missing-key restore. A different workload could reach a recovery target and fail later on encrypted data access.

The pgBackRest repository used encryption and the current documented wrapper/synchronous archiving configuration. The WAL wrapper can expose transient plaintext in shared memory; no end-to-end absence-of-plaintext or cryptographic security proof is claimed.

EXPLAIN JSON is plan evidence, not runtime operator instrumentation. Three rounds on one host are repeatability, not cross-platform validation, production-scale endurance, performance, memory or disk-sizing evidence. Host openssl output does not identify each process's dynamically loaded library.

No external KMS, multiple rotations, server/WAL-key rotation, standby failover, concurrent backup/key rotation, incremental chain, cross-version restore, tablespace relocation or production incident was tested. The experiment does not establish safe deletion of a key while any retained recovery path still depends on it.

## Novelty wording

The review did not find the complete controlled nine-case key-availability/recovery-target matrix with these acceptance checks in the inspected Percona material. This is a bounded search result, not proof that no one has ever published it. Retaining older keys, avoiding rotation during backup and taking a new full backup after rotation are already documented. Ordinary PITR with pg_tde and pgBackRest is also already published.

No claim of worldwide priority, superiority over every comparable article, editorial acceptance or production expertise follows from this evidence.
