# Which Keys Does a pg_tde Restore Need? A Nine-Case Rotation Lab

**Haifeng Cheng**

All nine repository checks returned success. All nine pgBackRest file-restore commands also returned success. Only five recovery paths reached their requested target with the complete encrypted data intact.

The difference was the database principal key available to the restored instance. A backup taken before rotation needed the old key to recover to an earlier target. Replaying that same backup across the rotation needed both keys. A new full backup taken after rotation recovered with the new key alone.

These are results from a small, repeatable lab, not a production incident. AI/model assistance was used for research, code and writing; execution and checks were automated. The companion includes the tested runner, recorded outputs and checksums.

## The question is a recovery path, not a backup date

Percona already documents that [older encrypted backups need accessible older principal keys](https://docs.percona.com/pg-tde/how-to/restore-backups.html). Its [key-management guidance](https://docs.percona.com/pg-tde/global-key-provider-configuration/overview.html) also says to rotate outside backup windows and take a new full backup afterwards. This lab follows those instructions. Neither recommendation is a new finding.

The narrower question is which keys a particular **backup-to-target path** needs. A successful backup made under K0 does not tell us whether K0 alone can replay through a later transition to K1.

The existing [Percona pgBackRest walkthrough](https://percona.community/blog/2026/03/10/running-pgbackrest-with-pg_tde-a-practical-percona-walkthrough/) explains configuration and restoration. [Stefan Fercot's experiments](https://pgstef.github.io/2026/06/04/pgbackrest_and_pg_tde.html) already demonstrate pg_tde with pgBackRest and PITR. Here, the additional work is a controlled key-availability matrix, exact recovery-target checks and complete data comparisons.

## Keep three kinds of key separate

The tested stack was:

- Percona Server for PostgreSQL 18.7.1, based on PostgreSQL 18.7.
- pg_tde 2.2.2, confirmed with SELECT pg_tde_version().
- pgBackRest 2.60.0.
- Ubuntu 24.04.5 LTS, x86_64. The host openssl command reported 3.0.13.

The official distribution tarball and individual binary hashes are recorded in the companion. Its filename contains ssl3.5; the host version above is not proof of the library loaded by each database binary. Dynamic-library resolution was not separately recorded. This is a pinned lab setup, not a production installation recommendation.

The lab replaces database principal key **K0**, in file provider p0, with **K1**, in file provider p1. It keeps the server/WAL principal key **W0** and the pgBackRest repository passphrase unchanged.

Both providers and both database keys existed before F0; the rotation changed which principal key was active. This isolates key-file availability rather than adding a newly created provider during replay.

Those are different layers. Principal-key replacement rewraps the database's internal keys; it does not mean every table page is rewritten. The [architecture documentation](https://docs.percona.com/pg-tde/architecture/key-provider-management.html) explains that hierarchy.

Local file providers make the experiment self-contained. They are not a recommended production KMS. The negative cases withhold replaceable copies of key-bearing files while retaining the originals. They test availability through those configured paths, not a remote KMS's access-control, deletion or versioning behaviour.

WAL uses the [currently documented supported configuration](https://docs.percona.com/pg-tde/wal-encryption.html): archive/restore wrappers, archive-async=n and the specified header/checksum settings. The repository is encrypted. The wrapper path temporarily handles plaintext WAL in shared-memory storage, so this is not a claim that plaintext never exists anywhere in the process.

## Build two backups and two precise targets

The encrypted ledger uses tde_heap, a primary-key index and large externally stored payload values. Every payload is included in the final comparison.

The sequence is deliberately ordered:

1. Create 256 synthetic rows under K0 and finish full backup F0.
2. Commit a deterministic update batch and create the named restore point before_rotation.
3. Replace K0 with K1, outside the completed backup window.
4. Commit another update batch, add 16 rows and finish full backup F1.
5. Record the complete after-state and create after_rotation.
6. Wait for the target WAL segment to be archived, then stop the source.

Each restore names its backup label explicitly. It cannot silently choose F1 when the case is supposed to exercise F0. Each also names its recovery target and starts in a new data directory with a cold server process.

The source verification reads are part of the workload too: they can generate WAL through page maintenance. In these runs, a post-F1 PRUNE_ON_ACCESS record became relevant to one negative case. The failure location is therefore a property of this fixture, not a universal promise about when every missing-key restore fails.

## The observed matrix

The same frozen runner completed three fresh rounds on one host. Each round created its own source, backups and keys.

| Starting backup and target | K0 and K1 available | Only K0 available | Only K1 available |
|---|---|---|---|
| F0 → before_rotation | Pass | Pass | Fails: K0 unavailable |
| F0 → after_rotation | Pass | Fails: K1 unavailable | Fails: K0 unavailable |
| F1 → after_rotation | Pass | Fails: K1 unavailable | Pass |

W0 and the repository passphrase remained available in every column.

All 27 core verify commands and all 27 file-restore commands returned zero. The nine cases in each round reused that round's repository; these were three repositories, not 27 independent ones. The 15 successful recoveries matched their complete source data; the other 12 failed with the relevant missing-key error. No unrelated connection error was accepted as a successful negative test.

The files were not corrupt merely because recovery failed. Repository verification and database recovery answer different questions. pgBackRest's [verify command checks repository contents](https://pgbackrest.org/command.html#command-verify); it does not execute the application's encrypted reads.

## Why crossing the rotation needs both keys

For F0 → after_rotation with only K0, the server recorded:

```text
FATAL: failed to retrieve principal key "K1" from key provider "p1" for database 5
CONTEXT: WAL redo at ... for pg_tde/ROTATE_PRINCIPAL_KEY: db: 5
```

The exact log retains the actual LSN, timestamp and process ID. The error and its redo context are adjacent and belong to the same process.

This matches the [2.2.2 replay implementation](https://raw.githubusercontent.com/percona/pg_tde/2.2.2/src/catalog/tde_principal_key.c). Rotation redo obtains the current principal key, retrieves the new key from its provider and rewraps internal keys. The [WAL dispatcher](https://raw.githubusercontent.com/percona/pg_tde/2.2.2/src/access/pg_tde_xlog.c) routes the rotation record to that code.

Keeping K0 made the old backup usable, but it did not supply K1 at the transition. Conversely, retaining K1 alone did not let F0 replay earlier updates to data whose internal keys were still wrapped under K0.

F1 starts on the other side of the transition. In this fixture it recovered with K1 alone. That does not authorise deleting K0 while F0 or another K0-dependent recovery path is still retained.

## Define success beyond “the command finished”

The acceptance checks were separate:

1. Repository verification and file restore both returned zero.
2. The server log named the requested restore point.
3. Recovery completed the requested promotion.
4. pg_last_wal_replay_lsn() equalled that run's recorded target LSN.
5. The target marker and row count matched.
6. An ordered CSV export of every row and full payload matched the source SHA-256.
7. The table remained encrypted tde_heap, and an index-based range query matched the reference aggregate.

EXPLAIN JSON showed an index-based plan for the range query, whose separately executed aggregate matched the reference. EXPLAIN ANALYZE was not used, so this is plan evidence, not a measured execution trace. Equivalent plan shapes were not required for data equality.

The before-state contained 256 rows and 1,050,512 exported bytes; the after-state contained 272 rows and 1,116,466 bytes. All three rounds produced the same two data hashes. Target LSNs were checked against each run's own source, not copied from another round.

Even pg_ctl start returned zero in the recorded missing-key cases before recovery subsequently failed. Connection readiness was therefore insufficient as an acceptance condition. The runner continued checking recovery and data, and it stopped each instance before changing key availability.

## A provider-path repair has another precondition

Two additional cases per round tested a stale local provider path. The key still existed at a different location.

First, recovery failed because the configured path could not supply K0. Then the lab attempted the documented offline provider-edit tool on a fresh restore directory, before its first startup. The tool refused:

```text
pg_tde_change_key_provider: error: cluster must be shut down
```

There was no running server in that directory, but pg_controldata reported **in production**, inherited from the online physical backup. “No process is running” and “the control file records a clean shutdown” were not interchangeable.

The [2.2.2 tool source](https://raw.githubusercontent.com/percona/pg_tde/2.2.2/src/bin/pg_tde_change_key_provider.c) checks for a clean shutdown state. This is a measured precondition, not evidence that the key has been destroyed. The lab did not alter pg_control to evade it.

A separate positive control used a copy of an already recovered, cleanly stopped F1 instance:

- Confirm the full data baseline.
- Move the K1 file and observe the encrypted read fail.
- Stop normally and confirm the clean control-file state.
- Change p1's path with the offline tool.
- Cold-start again and verify the complete data hash and index query.

That repair passed. It demonstrates provider relocation **after completed recovery and clean shutdown**. It does not show that the same command can repair a fresh online-backup restore before its first startup. Keep that distinction when applying the [provider-repair documentation](https://docs.percona.com/pg-tde/command-line-tools/pg-tde-change-key-provider.html).

## Reproduce or audit the result

The companion's README.md specifies the pinned download, hash checks, prerequisites and evidence map. From the prepared lab directory, these commands create three separate rounds and the clean-shutdown control:

```sh
mkdir -p runs artifacts
for n in r1 r2 r3; do python3 src/run_matrix.py --name "$n" || exit 1; done
python3 src/run_clean_provider_control.py --base r1 --name clean1
python3 src/verify_recorded_evidence.py --runs-root runs --rounds r1 r2 r3 --control clean1 --allow-unmanifested
```

Use a disposable non-root environment that permits local Unix sockets, and keep the execution session alive until completion. Do not use real keys or production data. The same verifier can audit the bundled recorded results without starting a database.

## Turn retention policy into a restore test

For each supported recovery path, record:

- The explicit backup label and recovery target.
- The database principal-key identifiers and provider configuration needed along the path.
- Separately, the WAL/server key and repository credential requirements.
- Repository status, target evidence and complete application-data validation.
- The last successful cold-recovery test.

The implication of the matrix is to retain keys for the recovery paths you promise, not merely for the database's current key setting. A new full backup changes which path is available; it does not make every older retained path independent of the old key.

This lab covers one database, one K0→K1 replacement across two file providers, a fixed WAL key and one software build. It does not validate external KMS failures, multiple rotations, server-key rotation, standby failover, concurrent key rotation during backup, or cross-version recovery. Three consistent rounds are repeatability evidence, not a performance benchmark or a universal recovery guarantee.

The reproducibility package contains the exact scripts, per-run source snapshots, results, logs and checksums. It deliberately excludes key files, repository passphrases, database directories and the backup repository itself.
