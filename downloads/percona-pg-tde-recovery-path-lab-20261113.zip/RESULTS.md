# Recorded results

## Core matrix, repeated three times

| Backup → target | Both K0/K1 | Only K0 | Only K1 |
|---|---|---|---|
| F0 → before_rotation | Complete recovery | Complete recovery | Missing K0 during Heap/UPDATE redo |
| F0 → after_rotation | Complete recovery | Missing K1 at pg_tde/ROTATE_PRINCIPAL_KEY | Missing K0 during earlier Heap/UPDATE redo |
| F1 → after_rotation | Complete recovery | Missing K1 during Heap2/PRUNE_ON_ACCESS redo | Complete recovery |

All 27 core verify commands and all 27 file-restore commands returned zero. There were 15 complete recoveries and 12 missing-key failures. The failing redo locations are observed for this fixture, not guaranteed failure phases for every workload. W0 and the repository credential remained available throughout.

## Additional controls

Each round also measured a stale provider path: K0 remained intact at another location, but recovery could not retrieve it through the configured path. Each round then attempted the offline path-edit tool before starting a fresh restored copy; it returned 1 with `cluster must be shut down`. pg_controldata reported `in production`. These are three path failures and three separately classified CLI refusals, not successful repairs.

`jp-provider-clean01` copied an already recovered, cleanly stopped F1 instance. Its baseline matched the full after-state; moving K1 caused an encrypted read to fail; normal shutdown produced `shut down`; offline provider relocation returned 0; a cold restart matched the complete after-state again. This single positive control supports repair after completed recovery and clean shutdown only.

## Deterministic data checks

| State | Rows | Full CSV bytes | SHA-256 |
|---|---:|---:|---|
| Before | 256 | 1,050,512 | ee7f96205ac29a97a2c0b38f7511cdc54b897db80aca33a0b37c0fa03acea60c |
| After | 272 | 1,116,466 | 2c7373487671ad3bca5348fa2fcbd9dff8102aa7335f4556b529df7f5cf9cd9f |

The CSV contains every ordered id, epoch and complete large payload. Twenty-three raw CSV outputs were independently rehashed: six source states, fifteen successful recoveries, and the clean control's baseline/repaired outputs. Every digest and byte count matched.

The range query over ids 71–193 returned 123 rows, id sum 16,236 and epoch sum 17 before / 62 after. EXPLAIN JSON showed Aggregate → Bitmap Heap Scan → Bitmap Index Scan. This is a planned index path and separately executed query result, not an EXPLAIN ANALYZE trace. All accepted data states reported `tde_heap` and encrypted=true.

## Actual execution timestamps

Times below are UTC command-start timestamps, not fabricated commit dates or precise elapsed-time benchmarks.

| Run | First command | Last command started |
|---|---|---|
| jp-round02 | 2026-11-13 17:24:21 | 2026-11-13 17:25:49 |
| jp-round03-review | 2026-11-13 17:27:06 | 2026-11-13 17:28:35 |
| jp-round04-review | 2026-11-13 17:29:07 | 2026-11-13 17:30:37 |
| jp-provider-clean01 | 2026-11-13 17:31:21 | 2026-11-13 17:31:22 |

## Evidence map

- `evidence/runs/<round>/metadata.json`: explicit F0/F1 backup labels, runtime pg_tde version, source hashes, per-run target LSNs and key identifiers.
- `results.json`: case outcomes, repository/restore return codes, exact target checks, full-data acceptance and negative-case errors.
- `events.json`: UTC command starts, return codes, timeouts and corresponding log names.
- `logs/*-digest.log`: complete source/restored CSV outputs; the first line is the command header.
- `logs/<case>-start-server.log`: recovery target and same-process causal error/redo context.
- `logs/*provider_path_repaired-control-data.log`: fresh-restore control-file state.
- `evidence/runs/jp-provider-clean01/`: distinct successful clean-shutdown relocation control.
- `runner_snapshot.py` and `runner_sha256.txt`: per-run frozen main script identity.
- `evidence/environment.txt`: original host/version/hash output.
- `evidence/EVIDENCE_MANIFEST.json`: sanitized hashes, original hashes and explicit five-field redaction record.

The frozen main runner SHA-256 is `36184d2d80c85d3bf1e5e1383c86a5bfb54b1d4deb88cf5725264e7bbebcbb2d`.
